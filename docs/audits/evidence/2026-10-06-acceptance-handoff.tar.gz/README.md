# Portable synthetic acceptance evidence

Public export approved by the owner. No browser profiles, cookies, real data, raw agent sessions or environment files are included. Machine paths are replaced in exported records; original PNG bytes/hashes are unchanged. `manifest.json` identifies original and exported hashes. JSON/report transport copies are sanitized derivatives, not byte-identical raw originals.

## Scope and status

Nine repairs are in the PR. Historical final-input local CI: 507 first-pass successes, zero skipped/unexpected/flaky. Current Today populated native pair: 34 PNGs, parent-checked JSON/hash/geometry/wire/source proof, NOT yet independently reviewed as a complete native pair. The earlier independent source/dev-native review is a different scope. Release is NO-GO. Full affected Today/Overview 172-cell matrix plus 16 compact checks, all-route/Night follow-up, H5 scores/H6 images/H7 reconciliation/H8 new fresh verification remain pending. Do not promote pre-shared-change matrix screenshots to current acceptance.

## Inspect without a workstation

Read `native/native-keyboard-results.json` and `native/postchecks-and-summary.json`; their PNG paths are relative to this extracted bundle. Open all 34 PNGs. Native images are 640x913 pixels at actual Chrome tab zoom 2 (640 CSS/DPR1 -> 320 CSS/DPR2), with nine overlapping viewport-only tiles/theme and distinct closed-opener/open-palette witnesses. All requests are synthetic. `gates/strict-ci-outcomes.json` is an explicit derivative of the 507-test raw report, with its original SHA; attachments were omitted. Before/after input snapshots describe the pre-documentation runtime checkpoint, not the new PR commit.

## Prepare an optional local replay (does NOT authorize a capture)

From the PR checkout, after reading its instructions and installing the declared toolchain/locked dependencies normally:

```sh
ROOT=$(pwd)
mkdir -p .tmp/acceptance-resume
tar -xzf docs/audits/evidence/2026-10-06-acceptance-handoff.tar.gz -C .tmp/acceptance-resume
ln -s "$ROOT" .tmp/acceptance-resume/source
```

The frozen harness imports `../source/apps/...`, so that symlink is required. It runs on the source-installed Playwright. Existing fixture/catalog assertions must remain intact. Built output is NOT bundled; run owning build/validation targets and record fresh build hashes before replay, without claiming those builds match old artifact bytes.

For a separately approved native replay, first check 5193/5195 are free, start `bun .tmp/acceptance-resume/harness/static-server.ts apps/iroha-web/build 5193` (and public-site/build 5195) with owned PID/log/cleanup tracking. Copy `replay/native-probe.mjs` into a NEW ignored run directory before executing it; `import.meta.dir` places output beside the copied script. Set absolute `IROHA_SOURCE_ROOT=$ROOT` and `IROHA_AUDIT_HARNESS=$ROOT/.tmp/acceptance-resume/harness`. Run Node `--check` for non-executing syntax verification, then installed Bun for actual TS/import.meta.dir runtime. Never use Bun `--check`; it executed probes in prior attempts. The two import lines are the only portability change. Never execute into the archived `native/` directory or overwrite its screenshots.

Matrix selection uses `AUDIT_STATES` against `route|state`, e.g. `^(today|overview)[|]`; unset width/mode overrides for the established 172 denominator. Always use an absolute harness config and fresh `AUDIT_OUTPUT_DIR`; use the source-installed Playwright, not bunx/npx resolution. Full/matrix/native replay is NEW work, requires a fresh source/build freeze and explicit authority, and must stop on failures without changing assertions or silently retrying.

## Retained failures and limits

Old formatting failure and stale CI-before-final-test edits are not erased by later success. Historical Bun syntax-check execution, refused navigation, serialized callback scope errors, premature navigation-position sampling, the READY-substring fanout bug and two overwritten/lost opener references remain history, not current images. Parent's 28-vs-29 observation expectation and reviewer's guessed compact filenames were corrected against actual source/records, not treated as product defects. The font-symlink snapshot error occurred before any CI invocation. Overview static-production chart paint/module discovery and 1,345 unmeasured text samples remain unsupported; dev-only success and token/box checks do not establish static paint or WCAG-wide conformance. Historical images/failures not included here remain in the original scratch archive and must not be reconstructed as genuine evidence.
