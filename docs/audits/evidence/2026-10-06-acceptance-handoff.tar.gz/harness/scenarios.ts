// Route/state scenario catalog for the replacement cockpit audit. Reuses the
// repo's persistent fixture modules; only gaps are filled with audit-authored
// responses typed from src/lib/api.ts (declared per scenario via `source`).
import type { Page } from "../source/apps/iroha-web/node_modules/@playwright/test/index.mjs";
import { installMotionFixtures } from "../source/apps/iroha-web/e2e/motion-fixtures";
import { installNightFixtures } from "../source/apps/iroha-web/e2e/night-fixtures";
import { installLibraryFixtures } from "../source/apps/iroha-web/e2e/library-fixtures";
import { installPatternsFixtures } from "../source/apps/iroha-web/e2e/patterns-fixtures";
import { installExpensesFixtures } from "../source/apps/iroha-web/e2e/expenses-fixtures";
import { installReportsFixtures } from "../source/apps/iroha-web/e2e/reports-fixtures";
import { installTogoFixtures } from "../source/apps/iroha-web/e2e/togo-fixtures";
import {
  installPilotFixtures,
  type Pilot,
  type Scenario,
} from "../source/apps/iroha-web/e2e/pilot-fixtures";
import {
  fakeSession,
  signedOut,
  firstRun,
} from "../source/apps/iroha-web/e2e/session";

export const PUBLIC = "http://127.0.0.1:5195";
export type Gate = { promise: Promise<void>; release: () => void };
export type Expect = "alert" | "loading" | "empty" | "none";
export type Sc = {
  route: string;
  state: string;
  path: string;
  expect: Expect;
  source: string; // where the data comes from
  commit?: boolean; // do not wait for load: first read is deferred
  rm?: boolean; // also run the reduced-motion variant at 1280 light
  setup: (page: Page, g: Gate) => Promise<any>;
  after?: (page: Page, fx: any, g: Gate) => Promise<void>;
};

const OWNER = {
  setup_required: false,
  authenticated: true,
  username: "synthetic-owner",
  display_name: "Synthetic owner",
};
const READS = (reads: string[]) => (fx: any) =>
  reads.forEach((r) => fx.failures.add(r));
const holdAll = (fx: any, reads: string[], g: Gate) =>
  reads.forEach((r) => fx.holds.set(r, g.promise));
const select = async (page: Page, name: string, _hint?: string) => {
  // Prefer the hinted option; otherwise pick a real option other than the current one, so a fixture bound change cannot make the harness select a missing value.
  const box = page.getByRole("combobox", { name, exact: true });
  const value = await box.evaluate((el: HTMLSelectElement, hint) => {
    const opts = Array.from(el.options).filter((o) => o.value && o.value !== el.value && !o.disabled);
    // Canonical month values are "YYYY-MM"; an old bare-month hint ("9") maps to the option ending in "-09".
    const month = /^\d{1,2}$/.test(hint ?? "") ? "-" + String(hint).padStart(2, "0") : null;
    return (opts.find((o) => o.value === hint) ?? (month ? opts.find((o) => o.value.endsWith(month)) : undefined) ?? opts[0])?.value ?? "";
  }, _hint);
  if (!value) throw new Error(`no alternate option in "${name}"`);
  await box.selectOption(value);
};
const click = (page: Page, name: string | RegExp) =>
  page.getByRole("button", { name }).first().click({ timeout: 5000 });
// State settling is the driver's explicit marker wait (matrix.spec.ts settle); no sleeps here.
const wait = async (_page: Page) => {};

const sc: Sc[] = [];
const add = (s: Sc) => sc.push(s);

// ---------- Motion ----------
const M = "motion";
const mPath = "/motion?date=2026-08";
const mReads = ["summary", "records", "series"];
const mFx = (f: (fx: any, g: Gate) => void) => async (page: Page, g: Gate) => {
  const fx = await installMotionFixtures(page);
  f(fx, g);
  return fx;
};
const mSrc = "e2e/motion-fixtures.ts";
add({ route: M, state: "populated", path: mPath, expect: "none", source: mSrc, rm: true, setup: mFx(() => {}) });
add({ route: M, state: "populated-lifetime", path: "/motion", expect: "none", source: mSrc, setup: mFx(() => {}) });
add({ route: M, state: "confirmed-empty-scope(2026-07)", path: "/motion?date=2026-07", expect: "empty", source: mSrc, setup: mFx(() => {}) });
add({ route: M, state: "unknown-distance", path: mPath, expect: "none", source: mSrc, setup: mFx((fx) => (fx.missingDistance = true)) });
add({ route: M, state: "deferred-first-read", path: mPath, expect: "loading", commit: true, source: mSrc, setup: mFx((fx, g) => (fx.hold = g.promise)) });
add({ route: M, state: "initial-503", path: mPath, expect: "alert", source: mSrc, setup: mFx((fx) => READS([...mReads, "bounds"])(fx)) });
for (const r of mReads)
  add({ route: M, state: `partial-${r}-503`, path: mPath, expect: "alert", source: mSrc, setup: mFx((fx) => fx.failures.add(r)) });
add({ route: M, state: "retained-deferred-refetch", path: mPath, expect: "loading", source: mSrc, setup: mFx(() => {}),
  after: async (page, fx, g) => { fx.hold = g.promise; await select(page, "Filter by month", "9"); await wait(page); } });
add({ route: M, state: "retained-failed-refetch", path: mPath, expect: "alert", source: mSrc, setup: mFx(() => {}),
  after: async (page, fx) => { mReads.forEach((r) => fx.failures.add(r)); await select(page, "Filter by month", "9"); await wait(page); } });
add({ route: M, state: "named-retry-success", path: mPath, expect: "none", source: mSrc, setup: mFx((fx) => fx.failures.add("records")),
  after: async (page, fx) => { fx.failures.clear(); await page.getByRole("button", { name: "Retry activities", exact: true }).click(); await wait(page); } });
add({ route: M, state: "second-page-503", path: mPath, expect: "alert", source: mSrc,
  setup: mFx((fx) => { fx.paginated = true; fx.pageFailures.add("2026-08"); }),
  after: async (page) => { await page.getByTestId("motion-load-sentinel").scrollIntoViewIfNeeded({ timeout: 5000 }); await wait(page); } });

// ---------- Night ----------
const N = "night";
const nReads = ["records", "year", "month", "lifetime", "bounds"];
const nSrc = "e2e/night-fixtures.ts";
const nFx = (f: (fx: any, g: Gate) => void) => async (page: Page, g: Gate) => {
  const fx = await installNightFixtures(page);
  f(fx, g);
  return fx;
};
const nPath = "/night?date=2026-08";
add({ route: N, state: "populated", path: nPath, expect: "none", source: nSrc, rm: true, setup: nFx(() => {}) });
add({ route: N, state: "populated-lifetime", path: "/night", expect: "none", source: nSrc, setup: nFx(() => {}) });
add({ route: N, state: "naps-only", path: nPath, expect: "none", source: nSrc, setup: nFx((fx) => (fx.napsOnly = true)) });
add({ route: N, state: "confirmed-empty", path: nPath, expect: "empty", source: nSrc, setup: nFx((fx) => (fx.empty = true)) });
add({ route: N, state: "deferred-first-read", path: nPath, expect: "loading", commit: true, source: nSrc, setup: nFx((fx, g) => holdAll(fx, nReads, g)) });
add({ route: N, state: "initial-503", path: nPath, expect: "alert", source: nSrc, setup: nFx((fx) => READS(nReads)(fx)) });
for (const r of ["records", "month", "lifetime"])
  add({ route: N, state: `partial-${r}-503`, path: nPath, expect: "alert", source: nSrc, setup: nFx((fx) => fx.failures.add(r)) });
add({ route: N, state: "retained-deferred-refetch", path: nPath, expect: "loading", source: nSrc, setup: nFx(() => {}),
  after: async (page, fx, g) => { holdAll(fx, ["records", "month"], g); await select(page, "Filter by month", "9"); await wait(page); } });
add({ route: N, state: "retained-failed-refetch", path: nPath, expect: "alert", source: nSrc, setup: nFx(() => {}),
  after: async (page, fx) => { READS(["records", "month"])(fx); await select(page, "Filter by month", "9"); await wait(page); } });
add({ route: N, state: "named-retry-success", path: nPath, expect: "none", source: nSrc, setup: nFx((fx) => fx.failures.add("records")),
  after: async (page, fx) => { fx.failures.clear(); await page.getByRole("button", { name: "Retry sleep sessions", exact: true }).click(); await wait(page); } });
add({ route: N, state: "second-page-503", path: nPath, expect: "alert", source: nSrc,
  setup: nFx((fx) => { fx.paginated = true; fx.pageFailures.add("2026-08"); }),
  after: async (page) => { await page.locator(".theme-load-more").scrollIntoViewIfNeeded({ timeout: 5000 }); await wait(page); } });

// ---------- Library ----------
const L = "library";
const lSrc = "e2e/library-fixtures.ts";
const lFx = (f: (fx: any, g: Gate) => void) => async (page: Page, g: Gate) => {
  const fx = await installLibraryFixtures(page);
  f(fx, g);
  return fx;
};
add({ route: L, state: "populated", path: "/library", expect: "none", source: lSrc, rm: true, setup: lFx(() => {}) });
add({ route: L, state: "zero-rated", path: "/library", expect: "none", source: lSrc, setup: lFx((fx) => (fx.zeroRating = true)) });
add({ route: L, state: "confirmed-empty", path: "/library", expect: "empty", source: lSrc, setup: lFx((fx) => (fx.empty = true)) });
add({ route: L, state: "deferred-first-read", path: "/library", expect: "loading", commit: true, source: lSrc, setup: lFx((fx, g) => holdAll(fx, ["records", "aggregates"], g)) });
add({ route: L, state: "initial-503", path: "/library", expect: "alert", source: lSrc, setup: lFx((fx) => READS(["records", "aggregates"])(fx)) });
add({ route: L, state: "partial-records-503", path: "/library", expect: "alert", source: lSrc, setup: lFx((fx) => fx.failures.add("records")) });
add({ route: L, state: "partial-aggregates-503", path: "/library", expect: "alert", source: lSrc, setup: lFx((fx) => fx.failures.add("aggregates")) });
add({ route: L, state: "retained-deferred-refetch", path: "/library", expect: "loading", source: lSrc, setup: lFx(() => {}),
  after: async (page, fx, g) => { holdAll(fx, ["records", "aggregates"], g); await page.getByRole("button", { name: "Books", exact: true }).click(); await wait(page); } });
add({ route: L, state: "retained-failed-refetch", path: "/library", expect: "alert", source: lSrc, setup: lFx(() => {}),
  after: async (page, fx) => { READS(["records", "aggregates"])(fx); await page.getByRole("button", { name: "Books", exact: true }).click(); await wait(page); } });
add({ route: L, state: "named-retry-success", path: "/library", expect: "none", source: lSrc, setup: lFx((fx) => fx.failures.add("aggregates")),
  after: async (page, fx) => { fx.failures.clear(); await page.getByRole("button", { name: "Retry library totals", exact: true }).click(); await wait(page); } });
add({ route: L, state: "second-page-503", path: "/library", expect: "alert", source: lSrc,
  setup: lFx((fx) => { fx.paginated = true; fx.pageFailures.add("all"); }),
  after: async (page) => { await page.getByRole("button", { name: "Load more", exact: true }).click({ timeout: 5000 }); await wait(page); } });

// ---------- Patterns ----------
const P = "patterns";
const pSrc = "e2e/patterns-fixtures.ts";
const pReads = ["bounds", "monthly", "yearly", "latest", "days"];
const pFx = (f: (fx: any, g: Gate) => void) => async (page: Page, g: Gate) => {
  const fx = await installPatternsFixtures(page);
  f(fx, g);
  return fx;
};
const pPath = "/patterns?date=2026&gran=month";
add({ route: P, state: "populated", path: pPath, expect: "none", source: pSrc, rm: true, setup: pFx(() => {}) });
add({ route: P, state: "populated-lifetime", path: "/patterns", expect: "none", source: pSrc, setup: pFx(() => {}) });
add({ route: P, state: "confirmed-empty", path: pPath, expect: "empty", source: pSrc, setup: pFx((fx) => (fx.empty = true)) });
add({ route: P, state: "deferred-first-read", path: pPath, expect: "loading", commit: true, source: pSrc, setup: pFx((fx, g) => holdAll(fx, pReads, g)) });
add({ route: P, state: "initial-503", path: pPath, expect: "alert", source: pSrc, setup: pFx((fx) => READS(pReads)(fx)) });
for (const r of ["monthly", "latest", "days"])
  add({ route: P, state: `partial-${r}-503`, path: pPath, expect: "alert", source: pSrc, setup: pFx((fx) => fx.failures.add(r)) });
add({ route: P, state: "retained-deferred-refetch", path: pPath, expect: "loading", source: pSrc, setup: pFx(() => {}),
  after: async (page, fx, g) => { holdAll(fx, ["monthly", "days", "latest"].map((r) => r + ":2025"), g); fx.holds.set("monthly", g.promise); await select(page, "Filter by year", "2025"); await wait(page); } });
add({ route: P, state: "retained-failed-refetch", path: pPath, expect: "alert", source: pSrc, setup: pFx(() => {}),
  after: async (page, fx) => { READS(["monthly", "yearly", "days"])(fx); await select(page, "Filter by year", "2025"); await wait(page); } });
add({ route: P, state: "named-retry-success", path: pPath, expect: "none", source: pSrc, setup: pFx((fx) => fx.failures.add("monthly")),
  after: async (page, fx) => { fx.failures.clear(); await page.getByRole("button", { name: "Retry monthly patterns", exact: true }).click(); await wait(page); } });

// ---------- Expenses ----------
const E = "expenses";
const eSrc = "e2e/expenses-fixtures.ts";
const eReads = ["bounds", "spending", "ledger"];
const ePath = "/expenses?date=2026-08";
const eFx = (f: (fx: any, g: Gate) => void) => async (page: Page, g: Gate) => {
  const fx = await installExpensesFixtures(page);
  f(fx, g);
  return fx;
};
add({ route: E, state: "populated", path: ePath, expect: "none", source: eSrc, rm: true, setup: eFx(() => {}) });
add({ route: E, state: "populated-year", path: "/expenses?date=2026", expect: "none", source: eSrc, setup: eFx(() => {}) });
add({ route: E, state: "observed-net-zero", path: ePath, expect: "none", source: eSrc, setup: eFx((fx) => (fx.netZero = true)) });
add({ route: E, state: "confirmed-empty", path: ePath, expect: "empty", source: eSrc, setup: eFx((fx) => (fx.empty = true)) });
add({ route: E, state: "deferred-first-read", path: ePath, expect: "loading", commit: true, source: eSrc, setup: eFx((fx, g) => holdAll(fx, eReads, g)) });
add({ route: E, state: "initial-503", path: ePath, expect: "alert", source: eSrc, setup: eFx((fx) => READS(eReads)(fx)) });
for (const r of ["spending", "ledger"])
  add({ route: E, state: `partial-${r}-503`, path: ePath, expect: "alert", source: eSrc, setup: eFx((fx) => fx.failures.add(r)) });
add({ route: E, state: "retained-deferred-refetch", path: ePath, expect: "loading", source: eSrc, setup: eFx(() => {}),
  after: async (page, fx, g) => { fx.holds.set("spending:2026-09", g.promise); fx.holds.set("ledger:2026-09", g.promise); await select(page, "Filter by month", "9"); await wait(page); } });
add({ route: E, state: "retained-failed-refetch", path: ePath, expect: "alert", source: eSrc, setup: eFx(() => {}),
  after: async (page, fx) => { fx.failures.add("spending:2026-09"); fx.failures.add("ledger:2026-09"); await select(page, "Filter by month", "9"); await wait(page); } });
add({ route: E, state: "named-retry-success", path: ePath, expect: "none", source: eSrc, setup: eFx((fx) => fx.failures.add("spending")),
  after: async (page, fx) => { fx.failures.clear(); await page.getByRole("button", { name: "Retry expense spending", exact: true }).click(); await wait(page); } });

// ---------- Reports ----------
const R = "reports";
const rSrc = "e2e/reports-fixtures.ts";
const rPath = "/reports?date=2026-08";
const rFx = (f: (fx: any, g: Gate) => void) => async (page: Page, g: Gate) => {
  const fx = await installReportsFixtures(page);
  f(fx, g);
  return fx;
};
add({ route: R, state: "populated", path: rPath, expect: "none", source: rSrc, rm: true, setup: rFx(() => {}) });
add({ route: R, state: "confirmed-empty", path: rPath, expect: "empty", source: rSrc, setup: rFx((fx) => (fx.empty = true)) });
add({ route: R, state: "deferred-first-read", path: rPath, expect: "loading", commit: true, source: rSrc, setup: rFx((fx, g) => fx.holds.set("2026-08", g.promise)) });
add({ route: R, state: "initial-503", path: rPath, expect: "alert", source: rSrc, setup: rFx((fx) => fx.failures.add("2026-08")) });
add({ route: R, state: "partial-bounds-503", path: rPath, expect: "alert", source: rSrc, setup: rFx((fx) => (fx.boundsFailure = true)) });
add({ route: R, state: "retained-deferred-refetch", path: rPath, expect: "loading", source: rSrc, setup: rFx(() => {}),
  after: async (page, fx, g) => { fx.holds.set("2026-09", g.promise); await select(page, "Filter by month", "9"); await wait(page); } });
add({ route: R, state: "retained-failed-refetch", path: rPath, expect: "alert", source: rSrc, setup: rFx(() => {}),
  after: async (page, fx) => { fx.failures.add("2026-09"); await select(page, "Filter by month", "9"); await wait(page); } });
add({ route: R, state: "named-retry-success", path: rPath, expect: "none", source: rSrc, setup: rFx((fx) => fx.failures.add("2026-08")),
  after: async (page, fx) => { fx.failures.clear(); await page.getByRole("button", { name: "Retry monthly report", exact: true }).click(); await wait(page); } });

// ---------- To-go ----------
const T = "to-go";
const tSrc = "e2e/togo-fixtures.ts";
const tFx = (f: (fx: any, g: Gate) => void) => async (page: Page, g: Gate) => {
  const fx = await installTogoFixtures(page);
  f(fx, g);
  return fx;
};
add({ route: T, state: "populated", path: "/to-go", expect: "none", source: tSrc, rm: true, setup: tFx(() => {}) });
add({ route: T, state: "confirmed-empty", path: "/to-go", expect: "empty", source: tSrc, setup: tFx((fx) => { fx.tasks = []; fx.jobs = []; }) });
add({ route: T, state: "deferred-first-read", path: "/to-go", expect: "loading", commit: true, source: tSrc, setup: tFx((fx, g) => holdAll(fx, ["tasks", "jobs"], g)) });
add({ route: T, state: "initial-503", path: "/to-go", expect: "alert", source: tSrc, setup: tFx((fx) => READS(["tasks", "jobs"])(fx)) });
add({ route: T, state: "partial-tasks-503", path: "/to-go", expect: "alert", source: tSrc, setup: tFx((fx) => fx.failures.add("tasks")) });
add({ route: T, state: "partial-jobs-503", path: "/to-go", expect: "alert", source: tSrc, setup: tFx((fx) => fx.failures.add("jobs")) });
add({ route: T, state: "named-retry-success", path: "/to-go", expect: "none", source: tSrc, setup: tFx((fx) => fx.failures.add("tasks")),
  after: async (page, fx) => { fx.failures.clear(); await page.getByRole("button", { name: "Retry tasks", exact: true }).click(); await wait(page); } });
add({ route: T, state: "retained-failed-poll", path: "/to-go", expect: "alert", source: tSrc, setup: tFx(() => {}),
  after: async (page, fx) => { fx.failures.add("jobs"); await page.clock.fastForward(120_000); await wait(page); } });

// ---------- Pilot-backed: Overview / Metrics / Public ----------
const pilot = (route: string, p: Pilot, state: string, scenario: Scenario, path: string, expectKind: Expect, rm = false): Sc => ({
  route, state, path, expect: expectKind, source: "e2e/pilot-fixtures.ts", rm,
  setup: (page) => installPilotFixtures(page, p, scenario),
});
const pilotDeferred = (route: string, p: Pilot, path: string, glob: string): Sc => ({
  route, state: "deferred-first-read", path, expect: "loading", commit: true,
  source: "e2e/pilot-fixtures.ts + audit gate overlay (public-states.spec pattern)",
  setup: async (page, g) => {
    const fx = await installPilotFixtures(page, p, "populated");
    await page.route(glob, async (r) => { await g.promise; await r.fallback(); });
    return fx;
  },
});
for (const [state, scenario, kind] of [
  ["populated", "populated", "none"], ["confirmed-empty", "empty", "empty"], ["initial-503", "error", "alert"],
  ["unknown-distance", "missing-distance", "none"], ["partial-distance-coverage", "partial-distance", "none"], ["single-year", "single-year", "none"],
] as [string, Scenario, Expect][])
  add(pilot("overview", "overview", state, scenario, "/overview", kind, state === "populated"));
add(pilotDeferred("overview", "overview", "/overview", "**/api/v1/**"));
for (const [state, scenario, kind] of [
  ["populated", "populated", "none"], ["confirmed-empty", "empty", "empty"], ["initial-503", "error", "alert"],
] as [string, Scenario, Expect][])
  add(pilot("metrics", "metrics", state, scenario, "/metrics?date=2026-08", kind, state === "populated"));
add(pilotDeferred("metrics", "metrics", "/metrics?date=2026-08", "**/api/v1/**"));
for (const [state, scenario, kind] of [
  ["populated", "populated", "none"], ["confirmed-empty", "empty", "empty"], ["initial-503", "error", "alert"],
  ["unknown-distance", "missing-distance", "none"], ["partial-distance-coverage", "partial-distance", "none"], ["single-year", "single-year", "none"],
] as [string, Scenario, Expect][])
  add(pilot("public-root", "public", state, scenario, PUBLIC, kind, state === "populated"));
add(pilotDeferred("public-root", "public", PUBLIC, "**/public/v1/**"));
for (const [state, scenario, kind] of [
  ["populated", "populated", "none"], ["initial-503", "error", "alert"],
] as [string, Scenario, Expect][])
  add(pilot("public-query-detail", "public", state, scenario, `${PUBLIC}/?activity=synthetic-2026`, kind, state === "populated"));
add(pilotDeferred("public-query-detail", "public", `${PUBLIC}/?activity=synthetic-2026`, "**/public/v1/**"));
add(pilot("public-query-detail", "public", "unknown-id(404-not-empty)", "populated", `${PUBLIC}/?activity=does-not-exist`, "none"));
add(pilot("public-query-detail", "public", "unknown-id-pending", "populated", `${PUBLIC}/?activity=does-not-exist`, "none"));
add(pilot("public-query-detail", "public", "unknown-id-503", "populated", `${PUBLIC}/?activity=does-not-exist`, "none"));

// ---------- Details (payloads copied from e2e/detail-recovery.spec.ts, which exports no module) ----------
const id = "00000000-0000-4000-8000-000000000003";
const detailPayloads: Record<string, unknown> = {
  [`/api/v1/media/${id}`]: {
    item: { id, title: "Synthetic detail book", media_type: "book", status: "planned", item_role: "standalone", last_update_at: "2026-08-15T12:00:00Z" },
    work: { id, work_kind: "book", primary_title: "Synthetic detail book", original_title: "", original_language: "", description: "" },
    creators: [], relations: [], events: [], updates: [],
  },
  [`/api/v1/sleep/${id}`]: { id, wake_date: "2026-08-15", started_at: "2026-08-14T22:00:00Z", ended_at: "2026-08-15T06:00:00Z", asleep_s: 25200, time_in_bed_s: 28800, efficiency: 0.875, deep_s: 3600, rem_s: 7200, is_main_sleep: true, source: "synthetic" },
  [`/api/v1/sleep/${id}/segments`]: [],
  [`/api/v1/activities/${id}`]: { id, title: "Synthetic detail run", sport_type: "run", started_at: "2026-08-15T12:00:00Z", ended_at: "2026-08-15T13:00:00Z", timezone: "Asia/Tokyo", duration_s: 3600, distance_m: 8000, source_kind: "synthetic" },
  [`/api/v1/activities/${id}/route`]: [],
  [`/api/v1/activities/${id}/samplings`]: [],
  [`/api/v1/activities/${id}/laps`]: [],
};
const detailFx = async (page: Page, g: Gate, fail: (p: string) => boolean, hold = false) => {
  const unknown: string[] = [];
  await page.route("**/api/v1/**", async (route) => {
    const path = new URL(route.request().url()).pathname;
    if (hold) await g.promise;
    if (!(path in detailPayloads)) { unknown.push(path); return route.fulfill({ status: 404, json: { error: "Unknown fixture read" } }); }
    return fail(path) ? route.fulfill({ status: 503, json: { error: "Synthetic detail unavailable" } }) : route.fulfill({ json: detailPayloads[path] });
  });
  await fakeSession(page, OWNER);
  return { unknown };
};
const detail = (route: string, path: string, primary: string, subs: string[]) => {
  const src = "copy of e2e/detail-recovery.spec.ts payloads (subresources are empty arrays: no populated route/laps/segments/samplings fixture exists)";
  add({ route, state: "populated(subresources-confirmed-empty)", path, expect: "none", source: src, rm: true, setup: (p, g) => detailFx(p, g, () => false) });
  add({ route, state: "deferred-first-read", path, expect: "loading", commit: true, source: src, setup: (p, g) => detailFx(p, g, () => false, true) });
  add({ route, state: "initial-503", path, expect: "alert", source: src, setup: (p, g) => detailFx(p, g, () => true) });
  add({ route, state: "partial-subresource-503", path, expect: "alert", source: src, setup: (p, g) => detailFx(p, g, (x) => subs.includes(x)) });
};
detail("motion-detail", `/motion/${id}`, `/api/v1/activities/${id}`, [`/api/v1/activities/${id}/route`, `/api/v1/activities/${id}/samplings`, `/api/v1/activities/${id}/laps`]);
detail("night-detail", `/night/${id}`, `/api/v1/sleep/${id}`, [`/api/v1/sleep/${id}/segments`]);
detail("library-detail", `/library/${id}`, `/api/v1/media/${id}`, []);
// library detail has one read only: partial duplicates initial; keep for uniformity

// ---------- Today ----------
const TD = "today";
const todaySrc = "audit-authored briefing typed from src/lib/api.ts BriefingResponse + shared DailyRow/SleepSession/Activity (e2e/today-recovery.spec.ts fixture only models sections: [])";
const status = { availability: "supported", collection: "covered", operation: "idle", freshness: "within_cadence" };
const populatedSections = [
  { key: "daily", schema: "daily-day.v1", state: "ready", status, data: { items: [{ id: "d1", day: "2020-08-15", steps: 9000, distance_km: 6.2, resting_hr: 55, hrv_sdnn: 48, spo2_avg: 97.5, respiratory_rate: 14.5, body_mass_kg: 70.2, ring: { move_kcal: 420, move_goal_kcal: 500, exercise_min: 31, exercise_goal_min: 30, stand_hours: 10, stand_goal_hours: 12 }, source: "synthetic", first_raw_file_id: "r", created_at: "2020-08-15T12:00:00Z", updated_at: "2020-08-15T12:00:00Z" }], has_more: false } },
  { key: "sleep", schema: "sleep-day.v1", state: "ready", status, data: { items: [{ id: "s1", wake_date: "2020-08-15", started_at: "2020-08-14T22:00:00Z", ended_at: "2020-08-15T06:00:00Z", time_in_bed_s: 28800, asleep_s: 25200, efficiency: 0.875, is_main_sleep: true, core_s: 14400, deep_s: 3600, rem_s: 7200, awake_s: 3600, unspecified_s: 0, source: "synthetic", first_raw_file_id: "r", created_at: "2020-08-15T12:00:00Z", updated_at: "2020-08-15T12:00:00Z" }], has_more: false } },
  { key: "activities", schema: "activities-day.v1", state: "ready", status, data: { items: [{ id: "a1", title: "Synthetic morning run", sport_type: "run", started_at: "2020-08-15T07:00:00Z", timezone: "UTC", distance_m: 8000, duration_s: 3000, source_kind: "synthetic", first_raw_file_id: "r", created_at: "2020-08-15T12:00:00Z", updated_at: "2020-08-15T12:00:00Z" }], has_more: false } },
];
const emptySections = ["daily", "sleep", "activities"].map((key) => ({ key, schema: `${key}-day.v1`, state: "empty", status: { ...status, collection: "covered_empty" }, data: { items: [], has_more: false } }));
const todayFx = async (page: Page, g: Gate, o: { sections?: unknown[]; fail?: string[]; hold?: boolean; tasks?: unknown[] }) => {
  const fx = { failures: new Set<string>(o.fail ?? []), unknown: [] as string[] };
  await page.route("**/api/v1/**", async (route) => {
    const url = new URL(route.request().url());
    const kind = url.pathname === "/api/v1/briefing" ? "briefing" : url.pathname === "/api/v1/tasks" ? "tasks" : url.pathname === "/api/v1/daily/dates" ? "calendar" : null;
    if (!kind) { fx.unknown.push(url.pathname); return route.fulfill({ status: 404, json: { error: "Unknown Today fixture" } }); }
    if (o.hold) await g.promise;
    if (fx.failures.has(kind)) return route.fulfill({ status: 503, json: { error: "Synthetic Today unavailable" } });
    return route.fulfill({ json: kind === "briefing" ? { date: url.searchParams.get("date"), previous_date: "2020-08-14", next_date: "2020-08-16", sections: o.sections ?? populatedSections } : kind === "calendar" ? ["2020-08-14", "2020-08-15"] : (o.tasks ?? []) });
  });
  await fakeSession(page, OWNER);
  return fx;
};
const task = { id: "t1", title: "Synthetic open task", status: "open", priority: 1, source: "web", due_date: "2020-08-15", created_at: "2020-08-10T00:00:00Z", updated_at: "2020-08-10T00:00:00Z" };
const tdPath = "/?date=2020-08-15";
add({ route: TD, state: "populated", path: tdPath, expect: "none", source: todaySrc + " (media section absent)", rm: true, setup: (p, g) => todayFx(p, g, { tasks: [task] }) });
add({ route: TD, state: "confirmed-empty(sections ready-empty)", path: tdPath, expect: "empty", source: todaySrc, setup: (p, g) => todayFx(p, g, { sections: emptySections }) });
add({ route: TD, state: "deferred-first-read", path: tdPath, expect: "loading", commit: true, source: todaySrc, setup: (p, g) => todayFx(p, g, { hold: true }) });
add({ route: TD, state: "initial-503", path: tdPath, expect: "alert", source: todaySrc, setup: (p, g) => todayFx(p, g, { fail: ["briefing", "tasks", "calendar"] }) });
for (const r of ["briefing", "tasks", "calendar"])
  add({ route: TD, state: `partial-${r}-503`, path: tdPath, expect: "alert", source: todaySrc, setup: (p, g) => todayFx(p, g, { fail: [r], tasks: [task] }) });
add({ route: TD, state: "section-unavailable(partial-dependency)", path: tdPath, expect: "alert", source: todaySrc,
  setup: (p, g) => todayFx(p, g, { sections: populatedSections.map((s) => (s.key === "sleep" ? { ...s, state: "unavailable", data: { items: [], has_more: false }, status: { ...status, operation: "failed" } } : s)) }) });
add({ route: TD, state: "named-retry-success", path: tdPath, expect: "none", source: todaySrc, setup: (p, g) => todayFx(p, g, { fail: ["tasks"], tasks: [task] }),
  after: async (page, fx) => { fx.failures.clear(); await page.getByRole("button", { name: "Retry daily tasks", exact: true }).click(); await wait(page); } });
add({ route: TD, state: "retained-failed-refetch(previous-day)", path: tdPath, expect: "alert", source: todaySrc, setup: (p, g) => todayFx(p, g, { tasks: [task] }),
  after: async (page, fx) => { fx.failures.add("briefing"); await page.getByRole("button", { name: /previous day/i }).first().click(); await wait(page); } });
// Auth-only synthetic seam: strict method/path/DTO fixture, no domain API is expected.
const authSession = (session: unknown) => ({ status: 200, body: session });
const loginSession = { setup_required: false, authenticated: true, username: "synthetic-owner", display_name: "Synthetic owner", csrf_token: "synthetic-csrf" };
const authScenario = (route: string, state: string, initial: unknown, mutation?: { path: string; status: number; body: unknown; pending?: boolean }, initialFailure = false): Sc => ({
  route, state, path: route === "auth-success" ? "/manual" : "/", expect: state.includes("pending") ? "loading" : state.includes("error") || state === "initial-read-failure" ? "alert" : "none",
  source: "audit-authored exact api.ts AuthSession/AuthError fixture; fake credentials only",
  commit: state.includes("pending"),
  setup: async (page, g) => {
    const requests: { method: string; path: string; status?: number; body?: unknown; error?: string }[] = [];
    const fx: any = { requests, mutation, initialFailure, pendingWitness: false, retryWitness: false };
    await page.route("**/api/v1/**", async (route) => {
      const req = route.request();
      const path = new URL(req.url()).pathname;
      const call: { method: string; path: string; status?: number; body?: unknown; error?: string } = { method: req.method(), path };
      requests.push(call);
      if (path === "/api/v1/auth/session" && req.method() === "GET") {
        if (state === "session-pending") { fx.pendingWitness = true; await g.promise; }
        if (initialFailure && requests.filter((r) => r.path === path).length === 1) { call.status = 503; return route.fulfill({ status: 503, json: { code: "temporarily_unavailable", message: "synthetic session unavailable" } }); }
        call.status = 200; return route.fulfill({ status: 200, json: requests.filter((r) => r.path === path).length > 1 ? signedOut : initial });
      }
      if (mutation && path === mutation.path && req.method() === "POST") {
        try { call.body = req.postDataJSON(); } catch { call.error = "non-JSON request"; }
        if (mutation.pending) { fx.pendingWitness = true; await g.promise; }
        call.status = mutation.status;
        return route.fulfill({ status: mutation.status, json: mutation.body });
      }
      call.status = 599; call.error = "unexpected auth/domain request";
      return route.fulfill({ status: 599, json: { code: "unexpected_request", message: "unmodeled request" } });
    });
    return fx;
  },
  after: mutation || initialFailure ? async (page, fx, g) => {
    if (initialFailure) {
      fx.initialAlertWitness = await page.getByRole("alert").filter({ hasText: "Couldn't reach Iroha." }).isVisible();
      await page.getByRole("button", { name: "Try again", exact: true }).click();
      await page.getByRole("heading", { name: "Sign in", exact: true }).waitFor({ timeout: 5000 });
      fx.retryWitness = true;
      return;
    }
    if (mutation.path.endsWith("/login")) {
      await page.getByLabel("Username").fill("synthetic-owner");
      await page.getByLabel("Password", { exact: true }).fill("fake-not-a-secret-123");
      await page.getByRole("button", { name: "Sign in", exact: true }).click();
    } else {
      await page.getByLabel("Username").fill("synthetic-owner");
      await page.getByLabel("Password", { exact: true }).fill("fake-not-a-secret-123");
      await page.getByLabel("Confirm password").fill("fake-not-a-secret-123");
      await page.getByRole("button", { name: "Create account", exact: true }).click();
    }
    if (mutation.pending) {
      await page.waitForFunction(() => Array.from(document.querySelectorAll("button")).some((b) => b.disabled && /Signing in|Creating account/.test(b.textContent || "")), undefined, { timeout: 5000 });
      fx.busyWitness = true;
    }
  } : undefined,
});
add(authScenario("auth-login", "session-pending", signedOut, undefined));
add(authScenario("auth-login", "signed-out", signedOut));
add(authScenario("auth-setup", "first-run", firstRun));
add(authScenario("auth-login", "initial-read-failure", signedOut, undefined, true));
add(authScenario("auth-login", "login-pending", signedOut, { path: "/api/v1/auth/login", status: 401, body: { code: "invalid_credentials", message: "invalid credentials" }, pending: true }));
add(authScenario("auth-login", "login-error", signedOut, { path: "/api/v1/auth/login", status: 401, body: { code: "invalid_credentials", message: "invalid credentials" } }));
add(authScenario("auth-setup", "setup-pending", firstRun, { path: "/api/v1/auth/setup", status: 503, body: { code: "temporarily_unavailable", message: "synthetic setup unavailable" }, pending: true }));
add(authScenario("auth-success", "login-success", signedOut, { path: "/api/v1/auth/login", status: 200, body: loginSession }));
add(authScenario("auth-success", "setup-success", firstRun, { path: "/api/v1/auth/setup", status: 200, body: loginSession }));
add(authScenario("auth-setup", "setup-error", firstRun, { path: "/api/v1/auth/setup", status: 503, body: { code: "temporarily_unavailable", message: "synthetic setup unavailable" } }));

// ---------- Manual ----------
add({ route: "manual", state: "static", path: "/manual", expect: "none", source: "session fake only (static content)", rm: true,
  setup: async (p) => { await p.route("**/api/v1/**", (r) => r.fulfill({ status: 404, json: {} })); await fakeSession(p, OWNER); return {}; } });

// ---------- Admin (audit-authored DTOs typed from src/lib/api.ts; only Sources has a persistent spec fixture, copied) ----------
const adminSrc = "audit-authored typed from api.ts (SystemInfo/JobSchedule/Job/ImportJob/RawFile/IntakeCredential); sources DTO copied from e2e/sources.spec.ts";
const T0 = "2026-10-01T12:00:00Z";
const conn = { id: "src_synthetic", provider: "health_auto_export", instance_key: "iphone-hae:test", display_name: "Test Health delivery", availability: "supported", collection: "unknown", operation: "idle", freshness: "within_cadence", expected_interval_s: 86400, next_expected_at: "2026-10-02T00:00:00Z", last_receipt: { id: "receipt_synthetic", raw_file_id: "raw_synthetic", source_kind: "health_auto_export", ingestion_mode: "incremental", received_at: T0 }, coverage: [], next_actions: [] };
const metricDef = { id: "daily.steps", domain: "daily", label: "Steps", description: "Synthetic daily steps", kind: "canonical", value_type: "number", unit: "count", short_unit: "steps", supported_grains: ["day", "month", "year"], dimensions: [], reducer: "sum", rollup: "sum", aggregation_version: "synthetic.v1", coverage_kind: "observed", semantic_color_token: "--accent", preferred_view: "line" };
const adminData = (empty: boolean): Record<string, unknown> => ({
  "/api/v1/admin/system": { parser_version: "synthetic.v1", migration_version: 42, database_bytes: 123456789, raw_file_count: empty ? 0 : 12, raw_file_bytes: empty ? 0 : 98765432, raw_file_purged_count: 0, cache_backend: "memory", timezone: "UTC", passkeys_enabled: true, server_time: T0 },
  "/api/v1/metrics": { schema: "metric-catalog.v1", metrics: empty ? [] : [metricDef] },
  "/api/v1/connections": { connections: empty ? [] : [conn, { ...conn, id: "src_manual", display_name: "Manual GPX", provider: "gpx", freshness: "overdue", last_receipt: null, next_expected_at: undefined }] },
  "/api/v1/admin/schedules": { items: empty ? [] : [{ kind: "health_export_fetch", enabled: true, schedule_kind: "interval", schedule_expr: "1h", next_run_at: "2026-10-01T13:00:00Z", last_run_at: T0 }] },
  "/api/v1/jobs": empty ? [] : [{ id: "j1", kind: "health_export_fetch", status: "completed", attempts: 1, max_attempts: 3, run_after: T0, created_at: T0, updated_at: T0 }, { id: "j2", kind: "gpx_import", status: "failed", attempts: 3, max_attempts: 3, run_after: T0, error_message: "synthetic parse failure", created_at: T0, updated_at: T0 }],
  "/api/v1/imports": empty ? [] : [{ id: "i1", raw_file_id: "rf1", status: "completed", parser_kind: "gpx", parser_version: "synthetic.v1", created_at: T0 }, { id: "i2", raw_file_id: "rf2", status: "failed", parser_kind: "fit", parser_version: "synthetic.v1", error_message: "synthetic failure", created_at: T0 }],
  "/api/v1/raw-files": empty ? [] : [{ id: "rf1", original_filename: "synthetic-run.gpx", content_type: "application/gpx+xml", size_bytes: 2048, source_kind: "gpx", uploaded_via: "web", created_at: T0 }, { id: "rf2", original_filename: "synthetic-activity.fit", content_type: "application/octet-stream", size_bytes: 4096, source_kind: "fit", uploaded_via: "web", created_at: T0 }],
  "/api/v1/admin/intake-credentials": { items: empty ? [] : [{ id: "c1", name: "synthetic-phone", created_at: T0, last_used_at: T0, revoked_at: null }, { id: "c2", name: "synthetic-old", created_at: T0, last_used_at: null, revoked_at: T0 }] },
});
const adminFx = async (page: Page, g: Gate, o: { empty?: boolean; fail?: boolean; hold?: boolean }) => {
  const fx = { fail: !!o.fail, unknown: [] as string[], requests: [] as { method: string; path: string; status?: number }[] };
  const data = adminData(!!o.empty);
  await page.route("**/api/v1/**", async (route) => {
    const request = route.request();
    const path = new URL(request.url()).pathname;
    const call: { method: string; path: string; status?: number } = { method: request.method(), path };
    fx.requests.push(call);
    if (o.hold) await g.promise;
    if (!(path in data)) { fx.unknown.push(path); call.status = 404; return route.fulfill({ status: call.status, json: { error: "Unknown synthetic endpoint" } }); }
    call.status = fx.fail ? 503 : 200;
    return fx.fail ? route.fulfill({ status: call.status, json: { error: "synthetic admin unavailable" } }) : route.fulfill({ status: call.status, json: data[path] });
  });
  await fakeSession(page, OWNER);
  return fx;
};
for (const tab of ["system", "sources", "jobs", "imports", "intake"]) {
  const path = `/admin?tab=${tab}`;
  add({ route: `admin-${tab}`, state: "populated", path, expect: "none", source: adminSrc, rm: true, setup: (p, g) => adminFx(p, g, {}) });
  add({ route: `admin-${tab}`, state: "confirmed-empty", path, expect: "empty", source: adminSrc, setup: (p, g) => adminFx(p, g, { empty: true }) });
  add({ route: `admin-${tab}`, state: "deferred-first-read", path, expect: "loading", commit: true, source: adminSrc, setup: (p, g) => adminFx(p, g, { hold: true }) });
  add({ route: `admin-${tab}`, state: "initial-503", path, expect: "alert", source: adminSrc, setup: (p, g) => adminFx(p, g, { fail: true }) });
  add({ route: `admin-${tab}`, state: "named-retry-success", path, expect: "none", source: adminSrc, setup: (p, g) => adminFx(p, g, { fail: true }),
    after: async (page, fx) => { fx.fail = false; const b = page.getByRole("button", { name: /^(Refresh|Retry)/ }).first(); if (await b.count()) { await b.click(); await wait(page); } else throw new Error("no Refresh/Retry button on this tab"); } });
}

const intakeExisting = { id: "intake-existing", name: "synthetic-existing", created_at: T0, last_used_at: null, revoked_at: null };
const intakeIssued = { id: "intake-issued", name: "primary", created_at: T0, last_used_at: null, revoked_at: null };
const adminIntakeRetainedFx = async (page: Page) => {
  const fx = { unknown: [] as string[], requests: [] as { method: string; path: string; status?: number }[] };
  await page.route("**/api/v1/**", async (route) => {
    const path = new URL(route.request().url()).pathname;
    fx.unknown.push(path);
    return route.fulfill({ status: 404, json: { code: "not_found", message: "unmodeled synthetic admin endpoint" } });
  });
  await page.route("**/api/v1/admin/intake-credentials", async (route) => {
    const request = route.request();
    const call = { method: request.method(), path: new URL(request.url()).pathname } as { method: string; path: string; status?: number };
    fx.requests.push(call);
    if (call.method === "POST") {
      call.status = 201;
      return route.fulfill({ status: call.status, json: { credential: intakeIssued, token: "synthetic-one-time-token" } });
    }
    const readCount = fx.requests.filter((item) => item.method === "GET").length;
    if (readCount === 1) {
      call.status = 200;
      return route.fulfill({ status: call.status, json: { items: [intakeExisting] } });
    }
    call.status = 503;
    return route.fulfill({ status: call.status, json: { code: "temporarily_unavailable", message: "synthetic refresh failure" } });
  });
  await fakeSession(page, OWNER);
  return fx;
};
add({ route: "admin-intake", state: "retained-failed-refetch", path: "/admin?tab=intake", expect: "alert", source: "audit-authored exact IntakeCredential fixture: successful initial GET, successful issue POST, failed refresh GET",
  setup: adminIntakeRetainedFx,
  after: async (page) => { await page.getByRole("button", { name: "Issue token", exact: true }).click(); await wait(page); } });

export const scenarios = sc.map((s) => {
  if (s.route === "public-query-detail" && s.state === "populated") return withPublicDetail(s, "populated");
  if (s.route === "public-query-detail" && s.state === "unknown-id(404-not-empty)") return withPublicUnknownResponse(s, 404);
  if (s.route === "public-query-detail" && s.state === "unknown-id-pending") return withPublicUnknownResponse(s, 404, true);
  if (s.route === "public-query-detail" && s.state === "unknown-id-503") return withPublicUnknownResponse(s, 503);
  return s;
});

function withPublicUnknownResponse(sc: Sc, status: 404 | 503, hold = false): Sc {
  const base = sc.setup;
  return {
    ...sc,
    commit: hold || sc.commit,
    source: `${sc.source} + explicit public unknown-id ${hold ? "pending-404" : status}`,
    setup: async (page, g) => {
      const fx = await base(page, g);
      const calls: { method: string; path: string; status?: number; body?: unknown }[] = [];
      await page.route("**/public/v1/activities/does-not-exist", async (route) => {
        const request = route.request();
        const call: { method: string; path: string; status?: number; body?: unknown } = {
          method: request.method(),
          path: new URL(request.url()).pathname,
        };
        calls.push(call);
        if (hold) await g.promise;
        call.status = status;
        call.body = status === 404
          ? { code: "not_found", message: "activity not found", request_id: "synthetic-request" }
          : { code: "temporarily_unavailable", message: "synthetic detail unavailable", request_id: "synthetic-request" };
        return route.fulfill({ status, json: call.body });
      });
      return { ...fx, expectedPublicUnknown: calls };
    },
  };
}

// Audit5 fixture gap-fill: the per-activity public endpoint was unserved in audit3.
// Synthetic, privacy-trimmed shape (PublicActivityDetail); no real coordinates.
function withPublicDetail(sc: Sc, scenario: Scenario): Sc {
  const base = sc.setup;
  return {
    ...sc,
    source: `${sc.source} + audit5 synthetic /public/v1/activities/{id}`,
    setup: async (page, g) => {
      const fx = await base(page, g);
      if (scenario === "populated")
        await page.route("**/public/v1/activities/synthetic-2026", (route) =>
          route.fulfill({
            json: {
              activity: { id: "synthetic-2026", sport_type: "run", title: "Synthetic run 2026", started_at: "2026-08-14T12:00:00Z", ended_at: "2026-08-14T13:02:00Z", timezone: "UTC", distance_m: 12500, duration_s: 3720, moving_time_s: 3600, elevation_gain_m: 80, avg_hr: 148, max_hr: 171, avg_pace_s_per_km: 297, source_kind: "gpx" },
              route: Array.from({ length: 12 }, (_, i) => ({ seq: i, lat: 10 + i * 0.001, lon: 10 + Math.sin(i) * 0.001, elevation_m: 20 + i, distance_m: i * 1000 })),
              samplings: Array.from({ length: 8 }, (_, i) => ({ id: `s${i}`, sampling_type: "heart_rate", ts: `2026-08-14T12:${String(i * 7).padStart(2, "0")}:00Z`, value: 140 + i, unit: "bpm" })),
              laps: Array.from({ length: 3 }, (_, i) => ({ id: `l${i}`, lap_no: i + 1, distance_m: 4000, duration_s: 1200, avg_hr: 145 + i, avg_pace_s_per_km: 300 })),
            },
          }),
        );
      return fx;
    },
  };
}
