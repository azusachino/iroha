// Aggregates results/*.json into a per-(route,state) table and flag lists.
import { readdirSync, readFileSync, writeFileSync } from "node:fs";
const dir = "results";
const rows = readdirSync(dir).filter((f) => f.endsWith(".json") && !f.startsWith("_")).map((f) => JSON.parse(readFileSync(`${dir}/${f}`, "utf8")));
type G = { route: string; state: string; cells: any[] };
const groups = new Map<string, G>();
for (const r of rows) {
  const k = `${r.route}|${r.state}`;
  if (!groups.has(k)) groups.set(k, { route: r.route, state: r.state, cells: [] });
  groups.get(k)!.cells.push(r);
}
const out: string[] = [];
out.push(`cells=${rows.length} groups=${groups.size}`);
out.push("route | state | cells | harnessErr | afterErr | stateSignalMiss | rootOvf | pageOvfElems | clippedText | ctrlClipped | <24 ctrls(max) | contrastFails(max) | noFocusIndicator | focusOffX | focusObscured | pageErrs | unknownReqs");
for (const g of [...groups.values()].sort((a, b) => (a.route + a.state).localeCompare(b.route + b.state))) {
  const c = g.cells.filter((x) => !x.reducedMotion);
  const n = (f: (x: any) => number) => c.filter((x) => !x.harnessError && f(x) > 0).length;
  const mx = (f: (x: any) => number) => Math.max(0, ...c.filter((x) => !x.harnessError).map(f));
  out.push([
    g.route, g.state, `${g.cells.length}/${c.length}`,
    c.filter((x) => x.harnessError).length,
    c.filter((x) => x.afterError).length,
    c.filter((x) => !x.harnessError && !x.summary.expectSignalObserved).length,
    n((x) => (x.summary.rootOverflow ? 1 : 0)),
    n((x) => x.audit.pageOverflow.length),
    n((x) => x.audit.clippedText.length),
    n((x) => x.summary.controlsClippedOutsideViewport),
    mx((x) => x.summary.controlsUnder24Count),
    mx((x) => x.summary.contrastFails),
    n((x) => x.focusSummary.noIndicator.length),
    n((x) => x.focusSummary.offscreenX.length),
    n((x) => x.focusSummary.obscured.length),
    c.filter((x) => x.pageErrors.length).length,
    c.filter((x) => x.fixtureUnknown?.length).length,
  ].join(" | "));
}
writeFileSync("aggregate.txt", out.join("\n"));
console.log(out.join("\n"));
