// Audit-only config. Servers are started separately (web 5193, public 5195) so the
// lead's gate ports 5183/5184 are never touched. Not part of the repo.
import { mkdirSync } from "node:fs";
import { join } from "node:path";
import { defineConfig, devices } from "../source/apps/iroha-web/node_modules/@playwright/test/index.mjs";

const runDir = process.env.AUDIT_OUTPUT_DIR;
if (!runDir) throw new Error("AUDIT_OUTPUT_DIR must point to an isolated run directory");
mkdirSync(runDir, { recursive: true });

export default defineConfig({
  testDir: ".",
  testMatch: /matrix\.spec\.ts$/,
  testIgnore: ["**/runs/**"], // Archived collectors are evidence, not active tests.
  timeout: 90_000,
  workers: Number(process.env.AUDIT_WORKERS ?? 1),
  projects: [{ name: "chromium", use: { ...devices["Desktop Chrome"] } }],
  retries: 0,
  reporter: [["list"], ["json", { outputFile: join(runDir, "playwright-report.json") }]],
  outputDir: join(runDir, "pw-output"),
  use: {
    actionTimeout: 6000,
    ...devices["Desktop Chrome"],
    baseURL: "http://127.0.0.1:5193",
  },
});
