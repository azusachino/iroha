// Static server for already-built SPA output; no build, no source writes. SPA fallback to index.html.
import { existsSync, statSync } from "node:fs";
import { join, normalize } from "node:path";
const [root, port] = [process.argv[2], Number(process.argv[3])];
Bun.serve({
  hostname: "127.0.0.1",
  port,
  fetch(req) {
    const p = normalize(decodeURIComponent(new URL(req.url).pathname)).replace(/^(\.\.[/\\])+/, "");
    const file = join(root, p);
    if (existsSync(file) && statSync(file).isFile()) return new Response(Bun.file(file));
    return new Response(Bun.file(join(root, "index.html")), { headers: { "content-type": "text/html" } });
  },
});
