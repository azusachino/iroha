// Scratch cockpit preflight driver. Writes per-run records/screenshots and fails after saving
// them whenever scenario markers, fixture/request contracts, or browser execution fail.
import { test } from "../source/apps/iroha-web/node_modules/@playwright/test/index.mjs";
import { mkdirSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { measurePilotPage } from "../source/apps/iroha-web/e2e/pilot-measurements";
import { scenarios, type Gate } from "./scenarios";

const WIDTHS = process.env.AUDIT_WIDTHS ? process.env.AUDIT_WIDTHS.split(",").map(Number) : [320, 375, 414, 768, 1280];
const MODES = (process.env.AUDIT_MODES?.split(",") ?? ["light", "dark"]) as ("light" | "dark")[];
const SHOT = new Set(WIDTHS.flatMap((w) => MODES.map((m) => `${w}-${m}`)));
const only = process.env.AUDIT_ONLY; // optional route filter (regex)
const OUT = process.env.AUDIT_OUTPUT_DIR;
if (!OUT) throw new Error("AUDIT_OUTPUT_DIR must point outside the frozen source");
const RESULTS = join(OUT, "results");
const SHOTS = join(OUT, "shots");
mkdirSync(RESULTS, { recursive: true });
mkdirSync(SHOTS, { recursive: true });

const safe = (s: string) => s.replace(/[^a-z0-9.-]+/gi, "_");

function audit() {
  const vw = innerWidth;
  const vis = (el: Element) => {
    const r = el.getBoundingClientRect();
    const s = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && s.visibility === "visible" && s.display !== "none" && !el.closest("[inert]");
  };
  const desc = (el: Element) => {
    const label = el.getAttribute("aria-label") || (el.textContent || "").trim().replace(/\s+/g, " ").slice(0, 40);
    return `${el.tagName.toLowerCase()}${el.id ? "#" + el.id : ""}${typeof el.className === "string" && el.className ? "." + el.className.trim().split(/\s+/).slice(0, 2).join(".") : ""} "${label}"`;
  };
  const clipper = (el: Element) => {
    for (let a = el.parentElement; a; a = a.parentElement) {
      if (a === document.documentElement || a === document.body) return null;
      const s = getComputedStyle(a);
      if (["auto", "scroll", "hidden", "clip"].includes(s.overflowX)) return { a, mode: s.overflowX };
    }
    return null;
  };
  const all = Array.from(document.querySelectorAll("body *")).filter(vis);
  const scrollers = all
    .filter((el) => ["auto", "scroll"].includes(getComputedStyle(el).overflowX) && el.scrollWidth > el.clientWidth + 1)
    .map((el) => ({ el: desc(el), client: el.clientWidth, scroll: el.scrollWidth, focusable: (el as HTMLElement).tabIndex >= 0, named: !!(el.getAttribute("aria-label") || el.getAttribute("aria-labelledby")), role: el.getAttribute("role") }));
  const pageOverflow = all
    .filter((el) => { const r = el.getBoundingClientRect(); return (r.right > vw + 1 || r.left < -1) && !clipper(el); })
    .slice(0, 8)
    .map((el) => { const r = el.getBoundingClientRect(); return { el: desc(el), left: Math.round(r.left), right: Math.round(r.right) }; });
  // text hidden by overflow:hidden/clip containers without a scroll affordance
  const clippedText = all
    .filter((el) => el.children.length === 0 && (el.textContent || "").trim())
    .filter((el) => { const c = clipper(el); if (!c || !["hidden", "clip"].includes(c.mode)) return false; const r = el.getBoundingClientRect(), cr = c.a.getBoundingClientRect(); return r.right > cr.right + 1 || r.left < cr.left - 1; })
    .slice(0, 8)
    .map((el) => desc(el));
  const ellipsized = all
    .filter((el) => el.children.length === 0 && (el.textContent || "").trim() && el.scrollWidth > el.clientWidth + 1 && ["hidden", "clip"].includes(getComputedStyle(el).overflowX))
    .slice(0, 8)
    .map((el) => desc(el));
  const text = (sel: string) => Array.from(document.querySelectorAll(sel)).filter(vis).map((el) => (el.textContent || "").trim().replace(/\s+/g, " ").slice(0, 140)).filter(Boolean);
  const alerts = text("[role=alert]");
  const statuses = text("[role=status],[aria-live]");
  const loadingTexts = [...statuses, ...text("p,span,div,small")].filter((t) => /^(loading|updating|checking)\b/i.test(t) && t.length < 80);
  const emptyTexts = text("p,span,div,small,td,li").filter((t) => /^(no |nothing |none )/i.test(t) && t.length < 100);
  const retryButtons = Array.from(document.querySelectorAll("button")).filter(vis).map((b) => b.getAttribute("aria-label") || (b.textContent || "").trim()).filter((t) => /retry|refresh/i.test(t));
  const tables = Array.from(document.querySelectorAll("table")).filter(vis).map((t) => ({ name: t.getAttribute("aria-label") || t.querySelector("caption")?.textContent?.trim() || null, rows: t.rows.length, inScroller: !!clipper(t) }));
  const unnamedGraphics = Array.from(document.querySelectorAll("canvas,svg[role=img],[role=img]"))
    .filter(vis)
    .filter((el) => !(el.getAttribute("aria-label") || el.getAttribute("aria-labelledby") || el.closest("[aria-label],[aria-labelledby],figure,[aria-hidden=true]")))
    .slice(0, 6)
    .map(desc);
  const tabs = Array.from(document.querySelectorAll("[role=tab]")).filter(vis).map((t) => { const r = t.getBoundingClientRect(); const c = clipper(t); return { name: (t.textContent || "").trim(), selected: t.getAttribute("aria-selected"), tabindex: t.getAttribute("tabindex"), left: Math.round(r.left), right: Math.round(r.right), w: Math.round(r.width), h: Math.round(r.height), inViewport: r.left >= -1 && r.right <= vw + 1, inScroller: !!c }; });
  const imgs = Array.from(document.images).filter(vis).map((i) => ({ alt: i.getAttribute("alt"), src: i.getAttribute("src")?.slice(0, 50) }));
  const h1 = Array.from(document.querySelectorAll("h1")).filter(vis).map((h) => (h.textContent || "").trim());
  const dialogs = Array.from(document.querySelectorAll("dialog[open],[role=dialog]")).filter(vis).length;
  return {
    docHeight: document.documentElement.scrollHeight,
    scrollers, pageOverflow, clippedText, ellipsized,
    alerts, statuses: statuses.slice(0, 6), loadingTexts: loadingTexts.slice(0, 5), emptyTexts: emptyTexts.slice(0, 6), retryButtons,
    tables, unnamedGraphics, tabs, imgs, h1, dialogs,
    title: document.title,
    theme: document.documentElement.dataset.theme ?? null,
    prefersDark: matchMedia("(prefers-color-scheme: dark)").matches,
    focusableInViewport: undefined as unknown,
  };
}

async function focusWalk(page: import("@playwright/test").Page, stops = 18) {
  await page.evaluate(() => { (document.activeElement as HTMLElement | null)?.blur?.(); window.scrollTo(0, 0); });
  const out: any[] = [];
  const seen = new Set<string>();
  for (let i = 0; i < stops; i++) {
    await page.keyboard.press("Tab");
    const info = await page.evaluate(() => {
      const el = document.activeElement as HTMLElement;
      if (!el || el === document.body) return { body: true };
      const s = getComputedStyle(el);
      const r = el.getBoundingClientRect();
      const name = el.getAttribute("aria-label") || (el.textContent || "").trim().replace(/\s+/g, " ").slice(0, 50) || el.getAttribute("title") || "";
      const cx = Math.min(Math.max(r.left + r.width / 2, 0), innerWidth - 1), cy = Math.min(Math.max(r.top + r.height / 2, 0), innerHeight - 1);
      const top = document.elementFromPoint(cx, cy);
      const obscured = !!top && !el.contains(top) && !top.contains(el);
      return {
        tag: el.tagName.toLowerCase(), role: el.getAttribute("role"), name,
        outline: `${s.outlineStyle} ${s.outlineWidth}`, hasShadow: s.boxShadow !== "none",
        indicator: (s.outlineStyle !== "none" && parseFloat(s.outlineWidth) > 0) || s.boxShadow !== "none",
        w: Math.round(r.width), h: Math.round(r.height), left: Math.round(r.left), right: Math.round(r.right), top: Math.round(r.top),
        inViewportX: r.left >= -1 && r.right <= innerWidth + 1,
        inViewportY: r.bottom > 0 && r.top < innerHeight,
        obscuredBy: obscured ? `${top!.tagName.toLowerCase()}.${(top as HTMLElement).className?.toString().slice(0, 30)}` : null,
        key: `${el.tagName}|${name}|${Math.round(r.left)}|${Math.round(r.top + scrollY)}`,
      };
    });
    if ((info as any).body) { out.push(info); break; }
    if (seen.has((info as any).key)) break;
    seen.add((info as any).key);
    out.push(info);
  }
  return out;
}

async function exactScrollerJourney(page: import("@playwright/test").Page, route: string) {
  const cases = route === "night"
    ? [["Focus sleep records to scroll all columns", "Night exact sleep records", 5]]
    : [
        ["Focus activity records to scroll all columns", "Motion exact activity records", 5],
        ["Focus movement series to scroll all columns", "Exact movement series scroll area", 4],
      ];
  const results: any[] = [];
  for (const [buttonName, regionName, expectedColumns] of cases) {
    const button = page.getByRole("button", { name: buttonName, exact: true });
    const box = await button.boundingBox();
    if (!box || box.height < 44) throw new Error(`${buttonName} missing or under 44px`);
    await button.focus();
    await page.keyboard.press("Enter");
    const region = page.getByRole("region", { name: regionName, exact: true });
    const focused = await region.evaluate((el) => el === document.activeElement);
    const dimensions = await region.evaluate((el) => ({ scroll: el.scrollWidth, client: el.clientWidth, before: el.scrollLeft }));
    if (!focused || dimensions.scroll <= dimensions.client) throw new Error(`${regionName} not focused/scrollable: ${JSON.stringify({ focused, ...dimensions })}`);
    await page.keyboard.press("ArrowRight");
    await page.waitForFunction(({ label, before }) => {
      const node = Array.from(document.querySelectorAll('[role="region"]')).find((el) => el.getAttribute("aria-label") === label);
      return !!node && node.scrollLeft > before;
    }, { label: regionName, before: dimensions.before }, { timeout: 5000 });
    const after = await region.evaluate((el) => el.scrollLeft);
    const columns = await region.getByRole("table").locator("thead th").count();
    const url = new URL(page.url());
    if (after <= dimensions.before || columns !== expectedColumns || url.searchParams.get("date") !== "2026-08")
      throw new Error(`${regionName} ArrowRight/table/scope assertion failed: ${JSON.stringify({ before: dimensions.before, after, columns, expectedColumns, url: url.search })}`);
    results.push({ button: buttonName, region: regionName, before: dimensions.before, after, columns, url: url.search });
  }
  return results;
}

async function tabKeyboard(page: import("@playwright/test").Page, expectedInitial: string) {
  const list = page.getByRole("tablist", { name: "Admin sections", exact: true });
  const tabs = list.getByRole("tab");
  const n = await tabs.count();
  if (n !== 5) throw new Error(`Admin sections tab count ${n}, expected 5`);
  const selected = () => list.locator('[role="tab"][aria-selected="true"]');
  const state = async () => ({
    id: await selected().getAttribute("id"),
    focusId: await page.evaluate(() => (document.activeElement as HTMLElement | null)?.id ?? ""),
    queryTab: new URL(page.url()).searchParams.get("tab"),
  });
  const expectState = async (id: string) => {
    await page.waitForFunction((wanted) => {
      const list = document.querySelector('[role="tablist"][aria-label="Admin sections"]');
      const tab = list?.querySelector('[role="tab"][aria-selected="true"]');
      return tab?.id === `admin-tab-${wanted}` && new URL(location.href).searchParams.get("tab") === wanted;
    }, id, { timeout: 5000 });
    const got = await state();
    if (got.id !== `admin-tab-${id}` || got.focusId !== `admin-tab-${id}` || got.queryTab !== id)
      throw new Error(`Admin tab ${id} identity/focus/query mismatch: ${JSON.stringify(got)}`);
    return got;
  };
  const rec: any = { count: n, initial: await state(), expectedInitial };
  if (rec.initial.id !== `admin-tab-${expectedInitial}` || rec.initial.queryTab !== expectedInitial)
    throw new Error(`wrong initial Admin tab: ${JSON.stringify(rec.initial)}`);
  const start = list.locator(`#admin-tab-${expectedInitial}`);
  await start.focus();
  if ((await state()).focusId !== `admin-tab-${expectedInitial}`) throw new Error("Admin focus did not start on selected tab");
  await page.keyboard.press("ArrowRight");
  rec.afterArrowRight = await expectState(({ system: "sources", sources: "jobs", jobs: "imports", imports: "intake", intake: "system" } as Record<string, string>)[expectedInitial]);
  await page.keyboard.press("End");
  rec.afterEnd = await expectState("intake");
  await page.keyboard.press("Home");
  rec.afterHome = await expectState("system");
  return rec;
}

// Two animation frames: a DOM-completion signal after a key press, not a sleep.
const frames = (page: import("@playwright/test").Page) => page.evaluate(() => new Promise<void>((r) => requestAnimationFrame(() => requestAnimationFrame(() => r()))));
// Explicit route/state marker wait (timeout unchanged at 10s); failure is persisted and then asserted. networkidle is used only for completed,
// non-polling states: held (deferred/updating) fixture requests never resolve, and To-go polls every 4s.
async function settle(page: import("@playwright/test").Page, sc: (typeof scenarios)[number], kind: string = sc.expect) {
  const marker = ({ kind, route }: { kind: string; route: string }) => {
    const vis = (el: Element) => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0 && !el.closest("[inert]"); };
    const texts = (sel: string) => Array.from(document.querySelectorAll(sel)).filter(vis).map((e) => (e.textContent || "").trim().replace(/\s+/g, " "));
    const loading = [...texts("[role=status],[aria-live]"), ...texts("p,span,div,small")].some((t) => /^(loading|updating|checking)\b/i.test(t) && t.length < 80);
    const ready = !!document.querySelector("main h1, main h2, main [role=tab], main table, main canvas, main svg");
    if (kind === "loading" && route === "admin-intake") return texts('section[aria-labelledby="intake-title"] [role=status]').some((t) => /^(Loading|Updating) intake tokens/i.test(t));
    if (kind === "loading" && route === "admin-system") return texts('[role=tabpanel] [role=status]').some((t) => /^loading\b/i.test(t));
    if (kind === "loading") return loading;
    if (kind === "alert" && route === "admin-intake") return texts('[role=alert]').some((t) => /Could not load intake tokens/i.test(t)) &&
      Array.from(document.querySelectorAll('section[aria-labelledby="intake-title"] button')).some((button) => vis(button) && (button.getAttribute("aria-label") || button.textContent || "").includes("Retry intake tokens"));
    if (kind === "alert") return texts("[role=alert]").length > 0;
    if (kind === "empty" && route === "admin-intake") return texts('section[aria-labelledby="intake-title"] [role=status]').length === 0 &&
      texts('section[aria-labelledby="intake-title"] span').includes("0 active") && texts('section[aria-labelledby="intake-title"] p').some((t) => /No tokens yet/.test(t));
    if (kind === "empty" && route === "patterns") {
      const paragraphs = texts("main p");
      const zeroPeriods = texts("main *").some((text) => text === "0 periods");
      return !loading && paragraphs.includes("Selected pattern scope: 2026 · all months") &&
        paragraphs.includes("Observed pattern scope: 2026 · all months") && zeroPeriods &&
        !texts("[role=alert]").length;
    }
    if (kind === "empty") return !loading && texts("p,span,div,small,td,li").some((t) => /^(no |nothing |none )/i.test(t) && t.length < 100);
    return ready && !loading && texts("[role=alert]").length === 0;
  };
  try { await page.waitForFunction(marker, { kind, route: sc.route }, { timeout: 10_000 }); } catch { return false; }
  const completed = kind !== "loading" && sc.route !== "to-go";
  if (completed) await page.waitForLoadState("networkidle", { timeout: 5_000 }).catch(() => {});
  await frames(page);
  return true;
}

const cells: { sc: (typeof scenarios)[number]; w: number; mode: (typeof MODES)[number]; rm: boolean }[] = [];
// Bounded preflight: tier A = one populated/static state at all widths x themes;
// tier B = the key unavailable state (initial-503) at 320 light/dark. Set AUDIT_STATES to
// a regex over "route|state" to expand a scenario set after its preflight passes.
const PRIMARY = /^(populated|populated\(subresources-confirmed-empty\)|static|signed-out|first-run|login-success|setup-success)$/;
const expand = process.env.AUDIT_STATES ? new RegExp(process.env.AUDIT_STATES) : null;
const seen = new Set<string>();
for (const sc of scenarios) {
  if (only && !new RegExp(only).test(sc.route)) continue;
  const key = `${sc.route}|${sc.state}`;
  if (expand) {
    if (!expand.test(key)) continue;
    for (const w of WIDTHS) for (const mode of MODES) cells.push({ sc, w, mode, rm: false });
    if (sc.rm && !process.env.AUDIT_WIDTHS) cells.push({ sc, w: 1280, mode: "light", rm: true });
    continue;
  }
  if (PRIMARY.test(sc.state) && !seen.has(sc.route + "A")) {
    seen.add(sc.route + "A");
    for (const w of WIDTHS) for (const mode of MODES) cells.push({ sc, w, mode, rm: false });
  } else if (sc.state === "initial-503") {
    for (const mode of MODES) cells.push({ sc, w: 320, mode, rm: false });
  }
}
for (const { sc, w, mode, rm } of cells) {
  const id = safe(`${sc.route}__${sc.state}__${w}__${mode}${rm ? "__rm" : ""}`);
  test(id, async ({ page }) => {
    const errors: string[] = [];
    const consoleErrors: string[] = [];
    const expectedHttpErrors: string[] = [];
    const apiRequests: any[] = [];
    const apiRequestFailures: any[] = [];
    const apiByUrl = new Map<string, any[]>();
    let fx: any;
    const failures: string[] = [];
    const publicPath = (url: string) => { try { return new URL(url).pathname; } catch { return ""; } };
    page.on("request", (request) => {
      const path = publicPath(request.url());
      if (!path.startsWith("/public/v1/") && !path.startsWith("/api/v1/")) return;
      const item = { method: request.method(), path, status: undefined as number | undefined };
      apiRequests.push(item);
      apiByUrl.set(request.url(), [...(apiByUrl.get(request.url()) ?? []), item]);
    });
    page.on("response", (response) => {
      const pending = apiByUrl.get(response.url());
      const item = pending?.shift();
      if (item) item.status = response.status();
    });
    page.on("requestfailed", (request) => {
      const path = publicPath(request.url());
      if (path.startsWith("/public/v1/") || path.startsWith("/api/v1/"))
        apiRequestFailures.push({ method: request.method(), path, failure: request.failure()?.errorText ?? "unknown" });
    });
    page.on("pageerror", (e) => errors.push((e.stack ?? e.message).slice(0, 300)));
    page.on("console", (m) => {
      if (m.type() !== "error") return;
      const text = m.text().slice(0, 200);
      if (/Failed to load resource: the server responded with a status of (401|404|503)/.test(text)) expectedHttpErrors.push(text);
      else consoleErrors.push(text);
    });
    await page.setViewportSize({ width: w, height: 900 });
    await page.emulateMedia({ colorScheme: mode, reducedMotion: rm ? "reduce" : "no-preference" });
    let release!: () => void;
    const g: Gate = { promise: new Promise<void>((r) => (release = r)), release: () => release() };
    const rec: any = { id, route: sc.route, state: sc.state, path: sc.path, width: w, mode, reducedMotion: rm, expect: sc.expect, source: sc.source };
    try {
      fx = await sc.setup(page, g);
      await page.goto(sc.path.startsWith("http") ? sc.path : sc.path, { waitUntil: sc.commit ? "commit" : "load" });
      rec.signalMiss = [];
      const sig = async (kind?: string) => { if (!(await settle(page, sc, kind))) rec.signalMiss.push(kind ?? sc.expect); };
      // States reached by an `after` step (refetch, page 2) start from a settled populated page.
      await sig(/^named-retry/.test(sc.state) || sc.state === "initial-read-failure" ? "alert" : sc.after && (sc.route.startsWith("auth-") || /^(retained|second-page)/.test(sc.state)) ? "none" : undefined);
      if (sc.state === "initial-read-failure") {
        rec.initialFailureWitness = await page.evaluate(() => ({ alert: document.querySelector('[role="alert"]')?.textContent?.trim() ?? null, retry: Array.from(document.querySelectorAll("button")).some((b) => b.textContent?.trim() === "Try again") }));
        await page.screenshot({ path: join(SHOTS, `${id}.before-retry.png`), fullPage: true });
      }
      if (sc.after) {
        try { await sc.after(page, fx, g); } catch (e) { rec.afterError = String((e as Error).message).slice(0, 300); }
        if (sc.state !== "initial-read-failure" && !["login-pending", "setup-pending"].includes(sc.state)) await sig(sc.state.endsWith("-pending") && sc.state !== "session-pending" ? "alert" : undefined);
      }
      if (["login-pending", "setup-pending"].includes(sc.state)) {
        const mutationPath = sc.state === "login-pending" ? "/api/v1/auth/login" : "/api/v1/auth/setup";
        const browserPosts = apiRequests.filter((request) => request.method === "POST" && request.path === mutationPath);
        const fixturePosts = (fx?.requests ?? []).filter((request: any) => request.method === "POST" && request.path === mutationPath);
        const rendered = await page.evaluate(() => ({
          disabled: Array.from(document.querySelectorAll("button")).some((button) => button.disabled && /Signing in|Creating account/.test(button.textContent || "")),
          alerts: Array.from(document.querySelectorAll('[role="alert"]')).map((alert) => alert.textContent?.trim()),
        }));
        const dto = fixturePosts[0]?.body;
        const exactDTO = JSON.stringify(Object.keys(dto ?? {}).sort()) === JSON.stringify(["password", "username"]) &&
          dto?.username === "synthetic-owner" && dto?.password === "fake-not-a-secret-123";
        rec.pendingCapture = {
          mutationPath,
          rendered,
          browserPosts: browserPosts.map((request) => ({ ...request })),
          fixturePosts: fixturePosts.map((request: any) => ({ ...request })),
          exactDTO,
          responseStillPending: browserPosts.length === 1 && browserPosts[0].status === undefined && fixturePosts.length === 1 && fixturePosts[0].status === undefined,
          capturedAt: "after interaction/state checks, before later route audits and driver cleanup",
        };
        rec.pendingCapture.passed = rendered.disabled && rendered.alerts.length === 0 && exactDTO && rec.pendingCapture.responseStillPending;
        rec.pendingCapture.screenshot = join(SHOTS, `${id}.pending-capture.png`);
        await page.screenshot({ path: rec.pendingCapture.screenshot, fullPage: true });
        writeFileSync(join(RESULTS, `${id}.json`), JSON.stringify(rec));
        if (!rec.pendingCapture.passed) failures.push(`mutation pending capture mismatch: ${JSON.stringify(rec.pendingCapture)}`);
      }
      rec.url = new URL(page.url()).pathname + new URL(page.url()).search;
      rec.fixtureUnknown = fx?.unknown ?? [];
      rec.fixtureRequests = fx?.requests?.map((request: any) => typeof request === "object" ? { ...request } : request) ?? [];
      const apiSnapshot = () => apiRequests.map((request) => ({ ...request }));
      rec.apiRequests = apiSnapshot();
      rec.publicRequests = rec.apiRequests.filter((request: any) => request.path.startsWith("/public/v1/"));
      rec.privateRequests = rec.apiRequests.filter((request: any) => request.path.startsWith("/api/v1/"));
      if (sc.route.startsWith("auth-")) {
        const sessionCalls = rec.privateRequests.filter((r: any) => r.path === "/api/v1/auth/session");
        const mutationCalls = rec.privateRequests.filter((r: any) => r.path === "/api/v1/auth/login" || r.path === "/api/v1/auth/setup");
        rec.authEvidence = { sessionCalls, mutationCalls, pendingWitness: fx?.pendingWitness ?? false, busyWitness: fx?.busyWitness ?? false, retryWitness: fx?.retryWitness ?? false, initialAlertWitness: fx?.initialAlertWitness ?? false, endpointRequests: fx?.requests?.map((request: any) => typeof request === "object" ? { ...request } : request) ?? [] };
        rec.authRendered = await page.evaluate(() => ({ h1: Array.from(document.querySelectorAll("main h1")).map((e) => e.textContent?.trim()), alerts: Array.from(document.querySelectorAll('[role="alert"]')).map((e) => e.textContent?.trim()), busy: Array.from(document.querySelectorAll("button")).some((b) => b.disabled && /Signing in|Creating account/.test(b.textContent || "")) }));
        const wrong = rec.privateRequests.filter((r: any) => !["/api/v1/auth/session", "/api/v1/auth/login", "/api/v1/auth/setup"].includes(r.path));
        if (wrong.length || rec.publicRequests.length) failures.push(`unexpected unauthenticated/domain requests: ${JSON.stringify({ wrong, public: rec.publicRequests })}`);
        if (sessionCalls.some((r: any) => r.method !== "GET")) failures.push(`session method mismatch: ${JSON.stringify(sessionCalls)}`);
        const expectedReads = sc.state === "initial-read-failure" ? [503, 200] : sc.state === "session-pending" ? [undefined] : [200];
        if (sessionCalls.length !== expectedReads.length || sessionCalls.some((r: any, i: number) => r.status !== expectedReads[i])) failures.push(`session status/count mismatch: ${JSON.stringify(sessionCalls)}`);
        if (sc.state === "session-pending" && (!fx?.pendingWitness || sessionCalls[0]?.status !== undefined)) failures.push(`session pending witness missing: ${JSON.stringify(rec.authEvidence)}`);
        if (sc.state === "initial-read-failure" && (!fx?.retryWitness || !fx?.initialAlertWitness || !rec.authRendered.h1.includes("Sign in"))) failures.push(`initial-read error/retry witness mismatch: ${JSON.stringify(rec.authEvidence)}`);
        const expectsMutation = sc.state.startsWith("login-") || sc.state.startsWith("setup-");
        if (mutationCalls.length !== (expectsMutation ? 1 : 0)) failures.push(`mutation count mismatch: ${JSON.stringify(mutationCalls)}`);
        for (const call of mutationCalls) {
          const requestEvidence = fx?.requests?.find((r: any) => r.path === call.path && r.method === call.method);
          const expectPath = sc.route === "auth-setup" || sc.state.startsWith("setup-") ? "/api/v1/auth/setup" : "/api/v1/auth/login";
          if (call.method !== "POST" || call.path !== expectPath) failures.push(`mutation endpoint/method mismatch: ${JSON.stringify(call)}`);
          if (JSON.stringify(Object.keys(requestEvidence?.body ?? {}).sort()) !== JSON.stringify(["password", "username"])) failures.push(`mutation DTO keys mismatch: ${JSON.stringify(requestEvidence)}`);
          if (requestEvidence?.body?.username !== "synthetic-owner" || requestEvidence?.body?.password !== "fake-not-a-secret-123") failures.push(`mutation fake credential mismatch: ${JSON.stringify(requestEvidence)}`);
        }
        if (["login-pending", "setup-pending"].includes(sc.state) && (!fx?.pendingWitness || !fx?.busyWitness || !rec.pendingCapture?.passed)) failures.push(`${sc.state} did not preserve the pending request/UI through capture`);
        if (sc.state === "login-error" && (mutationCalls[0]?.status !== 401 || !rec.authRendered.alerts.includes("Wrong username or password."))) failures.push(`login error DTO/state mismatch: ${JSON.stringify(rec.authEvidence)}`);
        if (sc.state === "setup-error" && (mutationCalls[0]?.status !== 503 || !rec.authRendered.alerts.includes("synthetic setup unavailable"))) failures.push(`setup error DTO/state mismatch: ${JSON.stringify(rec.authEvidence)}`);
        if ((sc.state === "login-success" || sc.state === "setup-success") && (mutationCalls[0]?.status !== 200 || !rec.authRendered.h1.length)) failures.push(`auth success/manual state mismatch: ${JSON.stringify(rec.authEvidence)}`);
        if (sc.state === "signed-out" && !rec.authRendered.h1.includes("Sign in")) failures.push("signed-out form not rendered");
        if (sc.state === "first-run" && !rec.authRendered.h1.includes("Welcome")) failures.push("setup-required form not rendered");
      }
      if (sc.route.startsWith("admin-") && sc.state === "populated") {
        const expected = sc.route.slice("admin-".length);
        rec.adminInitial = await page.evaluate(() => {
          const list = document.querySelector('[role="tablist"][aria-label="Admin sections"]');
          const selected = list?.querySelector('[role="tab"][aria-selected="true"]');
          return { id: selected?.id ?? null, label: selected?.textContent?.trim() ?? null, queryTab: new URL(location.href).searchParams.get("tab") };
        });
        if (rec.adminInitial.id !== `admin-tab-${expected}` || rec.adminInitial.queryTab !== expected)
          failures.push(`initial Admin tab identity mismatch: ${JSON.stringify(rec.adminInitial)}`);
      }
      if (sc.route === "public-query-detail") {
        const expectedDetailPath = sc.state === "populated" ? "/public/v1/activities/synthetic-2026" : "/public/v1/activities/does-not-exist";
        const allowed = new Set(["/public/v1/summary", "/public/v1/activities", "/public/v1/routes", "/public/v1/meta", expectedDetailPath]);
        const unexpected = rec.publicRequests.filter((r: any) => !allowed.has(r.path));
        if (unexpected.length) failures.push(`unexpected public API requests: ${JSON.stringify(unexpected)}`);
        if (rec.privateRequests.length) failures.push(`public page issued private API requests: ${JSON.stringify(rec.privateRequests)}`);
        for (const path of ["/public/v1/summary", "/public/v1/activities", "/public/v1/routes", "/public/v1/meta"]) {
          const calls = rec.publicRequests.filter((r: any) => r.path === path);
          if (calls.length !== 1 || calls[0].method !== "GET" || calls[0].status !== 200)
            failures.push(`public endpoint ${path} request mismatch: ${JSON.stringify(calls)}`);
        }
      }
      if (sc.route === "public-query-detail" && sc.state === "populated") {
        const endpoint = rec.publicRequests.filter((r: any) => r.path === "/public/v1/activities/synthetic-2026");
        rec.publicKnownDetail = endpoint;
        if (endpoint.length !== 1 || endpoint[0].method !== "GET" || endpoint[0].status !== 200)
          failures.push(`known public detail endpoint mismatch: ${JSON.stringify(endpoint)}`);
      }
      if (sc.route === "public-query-detail" && sc.state.startsWith("unknown-id")) {
        const endpoint = rec.publicRequests.filter((r: any) => r.path === "/public/v1/activities/does-not-exist");
        const fixtureResult = fx?.expectedPublicUnknown?.[0];
        const pending = sc.state === "unknown-id-pending";
        const expectedStatus = sc.state === "unknown-id(404-not-empty)" ? 404 : sc.state === "unknown-id-503" ? 503 : undefined;
        rec.publicUnknownDetail = endpoint;
        rec.publicUnknownFixture = fixtureResult ? { ...fixtureResult } : null;
        if (endpoint.length !== 1 || endpoint[0].method !== "GET" || endpoint[0].status !== expectedStatus)
          failures.push(`unknown public detail request/status mismatch: ${JSON.stringify(endpoint)}`);
        if (!fixtureResult || fixtureResult.method !== "GET" || fixtureResult.path !== "/public/v1/activities/does-not-exist" || fixtureResult.status !== expectedStatus)
          failures.push(`unknown public fixture status mismatch: ${JSON.stringify(fixtureResult)}`);
        if (expectedStatus === 404 && fixtureResult?.body?.code !== "not_found")
          failures.push(`unknown public 404 DTO mismatch: ${JSON.stringify(fixtureResult)}`);
        if (expectedStatus === 503 && fixtureResult?.body?.code !== "temporarily_unavailable")
          failures.push(`unknown public 503 DTO mismatch: ${JSON.stringify(fixtureResult)}`);
        const fallback = await page.evaluate(() => {
          const notice = document.querySelector('[role="status"][aria-label="Activity not found"]');
          return {
            h1: Array.from(document.querySelectorAll("main h1")).map((h) => h.textContent?.trim()),
            alerts: Array.from(document.querySelectorAll("[role=alert]")).map((e) => e.textContent?.trim()),
            activityQuery: new URL(location.href).searchParams.get("activity"),
            archiveRows: document.querySelectorAll('[aria-label="Public activity records"] tbody tr').length,
            emptyNotice: Array.from(document.querySelectorAll("main p")).some((p) => /No activities for this selection/.test(p.textContent || "")),
            notFoundNotice: notice?.textContent?.trim() ?? null,
            noticeLink: (notice as HTMLElement | null)?.querySelector("a")?.textContent?.trim() ?? null,
          };
        });
        rec.public404Fallback = fallback;
        const commonFallback = fallback.h1.includes("Public archive") && !fallback.alerts.length &&
          fallback.activityQuery === "does-not-exist" && fallback.archiveRows >= 1 && !fallback.emptyNotice;
        if (!commonFallback) failures.push(`public unknown-ID archive fallback mismatch: ${JSON.stringify(fallback)}`);
        if (expectedStatus === 404 && (!fallback.notFoundNotice?.includes("not in the public archive") || fallback.noticeLink !== "View the full archive"))
          failures.push(`confirmed-404 notice missing or incorrect: ${JSON.stringify(fallback)}`);
        if ((pending || expectedStatus === 503) && fallback.notFoundNotice)
          failures.push(`unconfirmed public ID incorrectly marked missing: ${JSON.stringify(fallback)}`);
        if (pending && Object.hasOwn(fixtureResult ?? {}, "status")) failures.push(`pending detail request already completed: ${JSON.stringify(fixtureResult)}`);
      }
      if (sc.route === "admin-intake") {
        const reads = rec.privateRequests.filter((r: any) => r.path === "/api/v1/admin/intake-credentials" && r.method === "GET");
        const mutations = rec.privateRequests.filter((r: any) => r.path === "/api/v1/admin/intake-credentials" && r.method === "POST");
        const panel = await page.evaluate(() => {
          const p = document.querySelector('section[aria-labelledby="intake-title"]');
          return {
            loading: p?.querySelector('[role="status"]')?.textContent?.trim() ?? null,
            alert: p?.querySelector('[role="alert"]')?.textContent?.trim() ?? null,
            retry: Array.from(p?.querySelectorAll("button") ?? []).some((b) => (b.getAttribute("aria-label") || b.textContent || "").includes("Retry intake tokens")),
            zeroActive: Array.from(p?.querySelectorAll("span") ?? []).some((el) => el.textContent?.trim() === "0 active"),
            noTokens: Array.from(p?.querySelectorAll("p") ?? []).some((el) => /No tokens yet/.test(el.textContent || "")),
            active: Array.from(p?.querySelectorAll("span") ?? []).map((el) => el.textContent?.trim()).find((text) => /^\d+ active$/.test(text || "")) ?? null,
            rows: Array.from(p?.querySelectorAll(".credential-list li strong") ?? []).map((el) => el.textContent?.trim()),
          };
        });
        rec.intakeEvidence = { reads, mutations, panel };
        if (sc.state === "deferred-first-read") {
          if (reads.length !== 1 || reads[0].status !== undefined || !/Loading intake tokens/i.test(panel.loading || "") || panel.zeroActive || panel.noTokens)
            failures.push(`Intake pending read truth mismatch: ${JSON.stringify(rec.intakeEvidence)}`);
        }
        if (sc.state === "confirmed-empty") {
          if (reads.length !== 1 || reads[0].status !== 200 || !panel.zeroActive || !panel.noTokens || panel.loading || panel.alert)
            failures.push(`Intake confirmed-empty mismatch: ${JSON.stringify(rec.intakeEvidence)}`);
        }
        if (sc.state === "initial-503") {
          if (reads.length !== 1 || reads[0].status !== 503 || !/Could not load intake tokens/i.test(panel.alert || "") || !panel.retry || panel.zeroActive || panel.noTokens)
            failures.push(`Intake failure/recovery affordance mismatch: ${JSON.stringify(rec.intakeEvidence)}`);
        }
        if (sc.state === "named-retry-success") {
          if (reads.length !== 2 || reads[0].status !== 503 || reads[1].status !== 200 || panel.alert || !panel.active?.startsWith("1 ") || !panel.rows.includes("synthetic-phone"))
            failures.push(`Intake named retry request/recovery mismatch: ${JSON.stringify(rec.intakeEvidence)}`);
        }
        if (sc.state === "retained-failed-refetch") {
          if (reads.length !== 2 || reads[0].status !== 200 || reads[1].status !== 503 || mutations.length !== 1 || mutations[0].status !== 201 ||
              !/Could not load intake tokens/i.test(panel.alert || "") || !panel.active?.startsWith("1 ") || !panel.rows.includes("synthetic-existing") || panel.noTokens)
            failures.push(`Intake retained-data failure mismatch: ${JSON.stringify(rec.intakeEvidence)}`);
        }
      }
      rec.pilot = await page.evaluate(measurePilotPage);
      rec.audit = await page.evaluate(audit);
      if (sc.route === "patterns") {
        rec.patternEvidence = await page.evaluate(() => ({
          paragraphs: Array.from(document.querySelectorAll("main p")).map((p) => (p.textContent || "").trim().replace(/\s+/g, " ")),
          zeroPeriodMarkers: Array.from(document.querySelectorAll("main *")).filter((node) => (node.textContent || "").trim() === "0 periods").map((node) => ({ tag: node.tagName.toLowerCase(), text: (node.textContent || "").trim() })),
        }));
      }
      const p = rec.pilot;
      rec.summary = {
        rootOverflow: p.scrollWidth > p.viewportWidth + 1,
        bodyOverflow: p.bodyWidth > p.viewportWidth + 1,
        contrastFails: p.textPairs.filter((t: any) => t.ratio < t.required).length,
        contrastFailSamples: p.textPairs.filter((t: any) => t.ratio < t.required).slice(0, 4).map((t: any) => `${t.text}|${t.ratio.toFixed(2)}<${t.required}`),
        unmeasuredText: p.unmeasuredText,
        controlsTotal: p.controls.length,
        controlsClippedOutsideViewport: p.controls.filter((c: any) => c.clipped).length,
        controlsUnder24: p.controls.filter((c: any) => c.width < 24 || c.height < 24).map((c: any) => `${c.tag}:${c.name.slice(0, 30)}:${Math.round(c.width)}x${Math.round(c.height)}`).slice(0, 8),
        controlsUnder24Count: p.controls.filter((c: any) => c.width < 24 || c.height < 24).length,
        smallFontControls: p.controls.filter((c: any) => parseFloat(c.fontSize) < 12).length,
        minControlFont: Math.min(...p.controls.map((c: any) => parseFloat(c.fontSize)).concat([99])),
        mainCount: p.mainCount,
        h1Count: rec.audit.h1.length,
        runningCssAnimations: p.runningCssAnimations,
        expectSignalObserved:
          sc.state === "initial-read-failure" ? !!fx?.initialAlertWitness && !!fx?.retryWitness
          : ["login-pending", "setup-pending"].includes(sc.state) ? !!rec.pendingCapture?.passed
          : sc.expect === "alert" ? rec.audit.alerts.length > 0
          : sc.expect === "loading" ? rec.audit.loadingTexts.length > 0
          : sc.expect === "empty" && sc.route === "patterns" ?
            rec.patternEvidence.paragraphs.includes("Selected pattern scope: 2026 · all months") &&
            rec.patternEvidence.paragraphs.includes("Observed pattern scope: 2026 · all months") &&
            rec.patternEvidence.zeroPeriodMarkers.length > 0
          : sc.expect === "empty" ? rec.audit.emptyTexts.length > 0
          : rec.audit.alerts.length === 0 && rec.audit.loadingTexts.length === 0,
      };
      if (SHOT.has(`${w}-${mode}`)) {
        await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur?.());
        await page.evaluate(() => window.scrollTo(0, 0));
        await page.screenshot({ path: join(SHOTS, `${id}.top.png`) });
        await page.screenshot({ path: join(SHOTS, `${id}.png`), fullPage: true });
        rec.screenshot = join(SHOTS, `${id}.png`);
      }
      rec.focus = await focusWalk(page);
      const f = rec.focus as any[];
      rec.focusSummary = {
        stops: f.length,
        noIndicator: f.filter((x) => !x.body && !x.indicator).map((x) => `${x.tag}:${x.name}`),
        offscreenX: f.filter((x) => !x.body && !x.inViewportX).map((x) => `${x.tag}:${x.name}`),
        obscured: f.filter((x) => x.obscuredBy).map((x) => `${x.tag}:${x.name}<-${x.obscuredBy}`),
        under24: f.filter((x) => !x.body && (x.w < 24 || x.h < 24)).map((x) => `${x.tag}:${x.name}:${x.w}x${x.h}`),
      };
      if (["motion", "night"].includes(sc.route) && sc.state === "populated") {
        rec.exactScrollerJourney = await exactScrollerJourney(page, sc.route);
      }
      if (sc.route.startsWith("admin-") && sc.state === "populated") {
        await page.reload({ waitUntil: "load" });
        if (!(await settle(page, sc, "none"))) throw new Error("Admin keyboard clean-reload state did not settle");
        rec.tabKeyboard = await tabKeyboard(page, sc.route.slice("admin-".length));
        await page.waitForLoadState("networkidle", { timeout: 5_000 }).catch(() => {});
      }
    } catch (e) {
      rec.harnessError = String((e as Error).message).slice(0, 500);
    } finally {
      rec.apiRequests = apiRequests.map((request) => ({ ...request }));
      rec.publicRequests = rec.apiRequests.filter((request: any) => request.path.startsWith("/public/v1/"));
      rec.privateRequests = rec.apiRequests.filter((request: any) => request.path.startsWith("/api/v1/"));
      rec.pageErrors = errors;
      rec.apiRequestFailures = [...apiRequestFailures];
      rec.consoleErrors = consoleErrors.slice(0, 5);
      rec.expectedHttpErrors = expectedHttpErrors;
      rec.validationFailures = failures;
      rec.fixtureUnknown = fx?.unknown ?? rec.fixtureUnknown ?? [];
      rec.fixtureRequests = fx?.requests?.map((request: any) => typeof request === "object" ? { ...request } : request) ?? rec.fixtureRequests ?? [];
      rec.apiRequests = apiRequests.map((request) => ({ ...request }));
      rec.publicRequests = rec.apiRequests.filter((request: any) => request.path.startsWith("/public/v1/"));
      rec.privateRequests = rec.apiRequests.filter((request: any) => request.path.startsWith("/api/v1/"));
      writeFileSync(join(RESULTS, `${id}.json`), JSON.stringify(rec));
      g.release();
    }
    if (rec.signalMiss?.length) failures.push(`semantic marker miss: ${rec.signalMiss.join(",")}`);
    if (rec.afterError) failures.push(`after action failed: ${rec.afterError}`);
    if (rec.harnessError) failures.push(`harness failed: ${rec.harnessError}`);
    if (rec.pageErrors?.length) failures.push(`page errors: ${rec.pageErrors.join("; ")}`);
    if (rec.consoleErrors?.length) failures.push(`console errors: ${rec.consoleErrors.join("; ")}`);
    if (rec.fixtureUnknown?.length) failures.push(`unexpected fixture requests: ${rec.fixtureUnknown.join(",")}`);
    if (rec.summary && !rec.summary.expectSignalObserved) failures.push("recorded semantic assertion is false");
    rec.validationFailures = failures;
    writeFileSync(join(RESULTS, `${id}.json`), JSON.stringify(rec));
    if (failures.length) throw new Error(`${failures.join(" | ")} (record saved: ${join(RESULTS, `${id}.json`)})`);
  });
}
