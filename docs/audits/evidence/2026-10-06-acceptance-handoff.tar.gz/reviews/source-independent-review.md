# Bounded shared-shell source/evidence review — completed cross-check

Read-only fresh reviewer follow-up. Scope remains the assigned bounded source/evidence review, not product/release acceptance. No source/test edits, browser/gate/build, derivative execution, staging, or external writes were performed. Read-only file inspection, Python JSON/SHA/PNG-header inspection, and Git read commands were used.

## Findings by criterion

1. **Minimal source repair: MET.** `UserMenu.svelte` preserves keyboard visibility on its three menuitems: actual evidence records solid 2px focus outline on Account settings, Admin and Log out. Light color `rgb(8, 115, 108)`, dark `rgb(109, 169, 255)`. `CommandPalette.svelte` changes selection with ArrowUp/Down, awaits Svelte `tick()`, then scrolls selected option with `block:'nearest'`; existing selected state/active descendant, listbox focus and Escape opener restore remain intact. Source/test inspection found no concrete regression in the authorized scope.

2. **New test semantics: MET for the targeted contract.** Source `shared-shell-keyboard.spec.ts` exercises overview fixtures, three account menuitems/Tab/Escape return, all 13 commands and wrap transitions, active selection/active descendant/listbox focus/scrollport containment, stable outer scroll and URL, metrics GET without query/body/status 200 and DTO, fixture unknowns and browser/API error guards. It covers both themes, motion preferences, compact widths and actual Chrome zoom. Distinguish this targeted contract from all-route H4/static-production proof.

3. **Native evidence/provenance: MET for requested evidence and records.** I opened all six native PNGs (indices 29/31/33 light, 65/67/69 dark), all requested compact PNGs (00/02 320 light normal; 21/23 390 light reduced; 36/38 320 dark normal; 57/59 390 dark reduced), and read their indexed attachment records. Correction to prior report: the four additionally requested images exist as `02-palette-selected-lower-light.png`, `23-palette-selected-lower-light.png`, `38-palette-selected-lower-dark.png`, `59-palette-selected-lower-dark.png`; I opened all four. No missing image finding remains.

   Actual images show 2px outline around focused account item in light/dark; selected lower `Steps` option visible at listbox bottom; and compact palette/menus within viewport. Six native JSON companions (30/32/34/66/68/70) were independently read and validated against their PNG bytes: SHA-256 matches index and attachment JSON; dimensions 640×913 match PNG header, DPR2 × 320×456 viewport; before/after viewport and scroll geometry unchanged. Account item rectangle is x≈105.8–300.6 and y≈228.4–343.5 across three 38.4px rows. Selected option metadata names `Steps\ndaily · count`, active descendant `command-12`, selected rect inside listbox; opener metadata identifies restored opener. All 72 files referenced by focused native index passed SHA-256 comparison against index (zero mismatches).

   Native observation records 35/71 independently read: **29** selected-name observations each, 13 distinct options, sequence covers 0, twelve Down steps, wrap Down to 0, twelve Up steps, wrap Up to 12 and final Down to 0; account focus entries are all active with solid 2px outline. Each native record reports six API requests, all GET: auth session, activity overview, routes, sleep overview, media aggregates, metrics; all six response status 200. API failure, console error, page error and unknown-fixture arrays empty. Correction: parent’s earlier hardcoded 28-observation expectation was wrong; implementation’s actual 29 is correct and not a product failure.

   Zoom records 28/64 both report native zoom 2, 640×913 DPR1 -> 320×456 DPR2, `cssZoom:"1"`, in light and dark. Compact requested PNGs were opened with `read`; these are representative witnesses only, not a WCAG-wide assessment.

4. **Gates/input integrity: UNMET for final-input strict full CI.** Reused raw final focused JSON/log reports 10 expected, zero skip/unexpected/flaky; Today regression 42 expected, zero skip/unexpected/flaky; validate log ends successfully (freeze records exit 0). Raw strict full CI JSON has 507 expected, zero skip/unexpected/flaky; paired config record says retries 2, failOnFlaky true. Crucially run `131121Z` predates final test-only theme/no-body and screenshot metadata assertions; focused and validate ran later, but do not cure that exact-input gap. No rerun performed and no waiver made.

5. **Prepared derivative: structurally reviewed, NOT EXECUTED.** Original helper hash independently matches `ae5949a5e1a0e29f4dc53ebb63933d90b99e14d55578c2a9cadb3d989e2b5f8a`; derivative matches `a3e558ee8bd0d5e262414e7bea05cd4c5bbbd9a9fa4f8269b015c0f097011e67`. Diff is limited to bounded clamped-navigation geometry wait after Enter and distinct closed-opener/open-selected-option screenshot names; no pointer or scroll action added. `pilot-keyboard.ts` itself polls the source-owned first-link clamped geometry after keyboard Enter. Diff callbacks are serialized inline and use passed values/local DOM lookups; no new external callback binding introduced. Derivative record explicitly says `executed:false`. Syntax/VM records are structural only; no DOM/native/H4 acceptance is attributed.

## Actual checkout and preservation checks

Read-only Git: branch `fix/intake-read-and-public-notice`, HEAD `086c8f2cf51a32f85c07b6ffd2e7943ae5631bf6`; `git diff --cached --quiet` exit 0 (empty index). Actual status matches checkpoint: six protected dirty paths plus three untracked specs. All six protected-original file hashes independently match `final-freeze.json`; all five root harness file hashes match freeze; `source/bun.lock` SHA-256 matches pre-edit hash. Owned source hashes also match freeze. Status is preserved/uncommitted; no staging or source changes made by reviewer.

## Residual boundaries

The only remaining criterion gap here is strict full CI for exact final test inputs (UNMET, owner’s one extra authorized run remains parent-owned/unspent). This report makes no final-state CI, H4, H8, or release acceptance claim. Release NO-GO and H4/H5–H8/authentication/passkeys/status-observers/unmeasured text/static-paint remain pending. No product failure inferred from the earlier mistaken 28-count or filename interpretation.

## Acceptance report

```acceptance-report
{
  "criteriaSatisfied": [
    {"id":"source-repair","status":"satisfied","evidence":"Reviewed owned components: tick/nearest listbox scrolling and recorded solid 2px outline for all three account menuitems in light/dark; no concrete in-scope regression."},
    {"id":"test-semantics","status":"satisfied","evidence":"Reviewed targeted test source and reused focused evidence; 13 options, keyboard wraps, geometry/focus/URL guards and API contract asserted."},
    {"id":"native-provenance","status":"satisfied","evidence":"Opened all 14 requested native/compact PNGs; verified all 72 index attachment hashes, six native PNG/JSON pairs, 29 observation sequence, API records and both native zoom records."},
    {"id":"final-input-strict-ci","status":"not-satisfied","evidence":"Strict 507-test run predates final test-only edits; no rerun performed."},
    {"id":"derivative-structural-review","status":"satisfied","evidence":"Original/derivative hashes verified; reviewed bounded diff, pilot-keyboard positioning semantics and unexecuted record. No browser acceptance claimed."}
  ],
  "changedFiles": [],
  "testsAddedOrUpdated": [],
  "commandsRun": [
    {"command":"python3 read-only JSON/SHA-256/PNG-header comparison over all 72 indexed native attachments, protected files, harness files, lock, observations and evidence records","result":"passed","summary":"No index attachment hash mismatch; protected 6, harness 5 and bun.lock match recorded hashes; native PNG pairs and derivative hashes verified."},
    {"command":"git -C <source> branch --show-current; git rev-parse HEAD; git diff --cached --quiet; git status --short --untracked-files=all","result":"passed","summary":"Expected branch/HEAD, empty index; status agrees with checkpoint."},
    {"command":"Read-only inspection of source, test, focused/Today/CI/validate records, zoom/observation records, native images and derivative diff/helper","result":"passed","summary":"Inspected/reused only; no test, gate, browser, or scratch probe executed."}
  ],
  "validationOutput": ["Focused 10/10; Today 42/42; make validate exit 0 — read from recorded run artifacts, not rerun.","Strict full CI 507/507, zero skipped/unexpected/flaky, retries=2/failOnFlaky=true — read from recorded artifacts; run predates final test inputs."],
  "residualRisks": ["Exact final test inputs lack strict full-CI run; this criterion remains unmet.","This narrow review does not attest H4/H8, all-route behavior, static-production proof, or release readiness."],
  "noStagedFiles": true,
  "diffSummary": "No reviewer edits. Independently checked source evidence, attachment integrity and preserved-path hashes.",
  "reviewFindings": ["no in-scope source blocker found","strict full CI exact-final-input gap remains open"],
  "manualNotes": "Corrected prior reviewer path misinterpretation: requested compact palette-selected images exist and were opened. Correct selectedNames count is 29 (not 28); both observations match the source traversal. Native screenshots are evidence, not WCAG-wide evaluation."
}
```