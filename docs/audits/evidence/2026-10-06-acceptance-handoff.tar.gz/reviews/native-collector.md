# Today native post-shared-source capture

**Result:** One authorized run completed for populated Today in light and dark. Both native probe records report `nativePass: true`, no assertion failures, no exceptions, and exit 0. This is only the authorized Today real-Chrome 200% pair, not whole H4 or release acceptance.

- Owned run: `<acceptance-workspace>/harness/runs/today-native-post-shared-source-20261006T150232Z/`
- Main evidence: `native-keyboard-results.json` (full records), `postchecks-and-summary.json` (all assertions, source/build post-freeze, every PNG reference/hash/dimension), `probe.log`, `probe.exit`, `prechecks.json`, `execution-lease.json`.
- Helper SHA-256 matched lease: `a3e558ee8bd0d5e262414e7bea05cd4c5bbbd9a9fa4f8269b015c0f097011e67`. Lease approval spent immediately before the sole Bun invocation.
- Setup validated the final frozen source identity: branch `fix/intake-read-and-public-notice`, HEAD `086c8f2cf51a32f85c07b6ffd2e7943ae5631bf6`, 890 source files unchanged, root harness five/build artifacts unchanged, expected nine dirty source paths, empty index. Font symlink targets and their tracked content were included in verification. Pre/post proof is in the run directory.
- The owned static servers returned HTTP 200 and exact current frozen build index hashes; only owned server PIDs 10410/10412 were started and stopped. Ports 5193/5195 had no listeners after cleanup.

## Observed capture and interaction results

Both themes used native Chrome extension tab zoom: baseline viewport 640×913 CSS at DPR 1; zoom readback 2; resulting viewport 320×456 CSS at DPR 2; CSS zoom remained 1; document/body width 320. Actual screenshot capture was CDP viewport-only at 640×913 pixels, `captureBeyondViewport:false`—not a CSS/pinch/DSF2 substitute.

Each theme has nine 640×913 Today tiles. Sticky header height was 158.57 CSS px; unobscured height 297.43 px; overlap 32 px; tile scroll step 265 px. The intervals in each theme were `[158.57,456]`, `[423.57,721]`, `[688.57,986]`, `[953.57,1251]`, `[1218.57,1516]`, `[1483.57,1781]`, `[1748.57,2046]`, `[2013.57,2311]`, `[2053.57,2351]`; union is gap-free through document height 2351. Both footer anchors were present and covered. All screenshot files are uniquely named; all 34 actual PNGs have integrity-checked JSON references, SHA-256 and dimensions in `postchecks-and-summary.json`.

Per theme: all 16 closed-state tab targets were visited; required focus flags (under 24px, offscreen, no indicator, obscured) were empty. Domains 4/4, Analyze 3/3, More 3/3 and account menu 3/3 entries were traversed; each closed by Escape. Date picker had 4 expected/visited tab stops; arrows visited all 31 August days, selected day and URL stayed unchanged. Command palette visited all 12 actual options; each active descendant remained visibly inside its listbox. URL/date/task state stayed unchanged, no route activation or task mutation occurred. API requests were GET-only, all status 200; no unknown fixture paths, failed requests, page errors or console errors. `/api/v1/metrics` was exactly one guarded `GET` without query/body and returned source-confirmed `{schema:"metric-catalog.v1",metrics:[]}`; the empty metric catalog is intentional for this probe.

## Validation commands

- Node 24.21.0 `--check` of immutable helper and isolated serialization checker: passed.
- Node isolated serialized callback regression at 640/DPR1 and 320/DPR2: passed.
- Helper SHA, source/head/status/index and 890-file/build/harness identity checks: passed (see `prechecks.json` and `postchecks-and-summary.json`).
- Started exact frozen static servers; HTTP GET both build roots: 200 and SHA matched frozen `index.html`.
- One authorized command: `bun <acceptance-workspace>/harness/runs/today-native-post-shared-source-20261006T150232Z/native-keyboard-derivative.mjs` (Bun 1.4.2, cwd `source/apps/iroha-web`): exit 0; no retries.
- Cleanup and listener check: passed; owned PIDs gone and no 5193/5195 listener.

**Residual scope/risks:** These records establish only this populated Today native pair and the probe's guards. They do not establish WCAG/contrast, screen-reader behavior, static Overview paint, H5–H8, all routes, release readiness, or whole H4. Night, status observers, all routes, and 1345 unmeasured text remain pending; parent must manually consume raw JSON and PNGs before any further action. No source, root harness, build, Git index, or staged files were changed. No reviewer was launched.

```acceptance-report
{
  "criteriaSatisfied": [
    {
      "id": "criterion-1",
      "status": "satisfied",
      "evidence": "Concise result and residual scope risks are recorded above; raw records and all capture references are in the named owned run directory."
    }
  ],
  "changedFiles": [],
  "testsAddedOrUpdated": [],
  "commandsRun": [
    {
      "command": "Node 24.21.0 --check immutable probe and serialization checker; Node isolated callback checker at 640/DPR1 and 320/DPR2",
      "result": "passed",
      "summary": "Both syntax checks and both serialized-layout checks passed."
    },
    {
      "command": "Frozen source/head/status/index/890-file/harness/build identity checks before and after capture",
      "result": "passed",
      "summary": "Expected source identity unchanged; no staged/index changes."
    },
    {
      "command": "Start owned frozen static servers; GET 127.0.0.1:5193/ and :5195/; stop owned PIDs and check listeners",
      "result": "passed",
      "summary": "Both HTTP 200 build bodies matched frozen index SHA-256; owned listeners removed."
    },
    {
      "command": "Bun 1.4.2 native-keyboard-derivative.mjs (single authorized invocation; source/apps/iroha-web cwd)",
      "result": "passed",
      "summary": "Exit 0; light and dark both nativePass true with no failures/exceptions; no retry."
    }
  ],
  "validationOutput": [
    "Light/dark: native Chrome extension zoom 2; 640x913 DPR1 baseline to 320x456 DPR2 CSS viewport; cssZoom=1; 9 gap-free viewport-only 640x913 captures per theme.",
    "Both themes: all keyboard/picker/menu/palette and no-mutation/API assertions passed; 34 PNG refs integrity-checked; post-source/build freeze and owned-process cleanup passed.",
    "Detailed commands, intervals, anchors, flags, requests, hashes, dimensions and source proof: .tmp/iroha-acceptance-2026-10-05/harness/runs/today-native-post-shared-source-20261006T150232Z/postchecks-and-summary.json"
  ],
  "residualRisks": [
    "This is only the authorized Today light/dark native pair, not whole H4 or release acceptance; WCAG/contrast, screen-reader behavior, static Overview paint, H5-H8, Night, status observers, all routes and 1345 unmeasured text remain pending.",
    "Parent must manually review raw PNG/JSON evidence before further action."
  ],
  "noStagedFiles": true,
  "diffSummary": "No source/root/build/index changes. Capture artifacts are confined to the owned run directory; this report is the managed output.",
  "reviewFindings": [
    "no blockers in the bounded native probe assertions; not a whole-H4/release review"
  ],
  "manualNotes": "Manual notes: this was the sole authorized attempt. Both theme JSON records report nativePass=true; no retries or reviewers were run. Consult postchecks-and-summary.json for every PNG digest/dimension and exact tile intervals."
}
```